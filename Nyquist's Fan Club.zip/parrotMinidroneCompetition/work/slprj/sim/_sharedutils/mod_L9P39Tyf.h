#ifndef SHARE_mod_L9P39Tyf
#define SHARE_mod_L9P39Tyf
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T mod_L9P39Tyf(real_T x);

#endif
