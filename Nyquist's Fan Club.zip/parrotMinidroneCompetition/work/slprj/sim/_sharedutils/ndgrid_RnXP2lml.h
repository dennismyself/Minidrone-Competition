#ifndef SHARE_ndgrid_RnXP2lml
#define SHARE_ndgrid_RnXP2lml
#include "rtwtypes.h"
#include "multiword_types.h"

extern void ndgrid_RnXP2lml(const real_T varargin_1[120], const real_T
  varargin_2[160], real_T varargout_1[19200], real_T varargout_2[19200]);

#endif
