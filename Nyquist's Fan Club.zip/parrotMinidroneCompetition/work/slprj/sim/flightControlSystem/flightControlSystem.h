#ifndef RTW_HEADER_flightControlSystem_h_
#define RTW_HEADER_flightControlSystem_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef flightControlSystem_COMMON_INCLUDES_
#define flightControlSystem_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "sf_runtime/sfc_sdi.h"
#endif
#include "flightControlSystem_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { int8_T fau3qf03xm ; } hrtts4l5bc ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real_T x_data [ 38400 ] ; real_T y [ 19200 ] ; real_T x [
19200 ] ; int16_T b_data [ 19200 ] ; boolean_T edu4rs0xq3_mbvzarwird [ 19200
] ; real_T dv [ 160 ] ; real_T dv1 [ 120 ] ; real32_T aujstwbrse_cl54gopm0x [
12 ] ; real32_T grhszs3sjk_kkiq3xxxve [ 9 ] ; real32_T grhszs3sjk_cxarnvbvui
[ 9 ] ; real_T awcyzczet0_bhxxfovxdy [ 4 ] ; real_T bkuhtmeamg_pbm3vprmfu [ 3
] ; real_T grhszs3sjk_cv5hdgrwft [ 3 ] ; real32_T fv [ 4 ] ; real_T
j5wzgpzqi4 [ 2 ] ; real_T centroid [ 2 ] ; real_T k0vc4prqez_fqdqrf4qbc [ 2 ]
; real32_T n2sgzma2gj_g2mlkqadfk [ 3 ] ; real32_T e5fgrdobej_g1smspu5ke [ 3 ]
; real_T bnbzowcxmh ; real_T ernp5tvitp [ 2 ] ; real_T ftda3noqkg ; real_T
nkkovac5ti ; real_T cyov5ky1ov ; real_T nmdhai2lmc [ 3 ] ; real_T hvdur1yjwa
; real_T h2ctrfi3m4 [ 2 ] ; real_T lxqvlboqdo [ 2 ] ; real_T fnzhxbxjia [ 2 ]
; real_T ozbnyngphj [ 2 ] ; real_T j42uqprebt [ 2 ] ; real_T pcafmpcl4b ;
real_T mTheta ; real_T total ; real_T count ; real_T angle ; real_T
a1bbiq2a3a_merlcviukg ; real_T c01pvjzgld_nz4o0shxby ; real_T
in00o5ix5a_idx_0 ; real_T in00o5ix5a_idx_1 ; real32_T ciysnkgium_ppxrqq0gsf [
2 ] ; real32_T nw12b21b42_llw0u2ae0v [ 2 ] ; real32_T oir0suwf2k_jwzvbuczlb [
2 ] ; real32_T kctmfodxtl_dhmrxtyqop [ 2 ] ; real32_T cy55xte2zg_guugdwf2m3 [
2 ] ; int32_T x_size [ 2 ] ; real32_T numAccum ; real32_T
ceqpqrxfmi_ldqodwenvz ; real32_T hrsldhjj3q_dhamdvybc1 ; real32_T
cgkzo2biyi_dypejvacrn ; real32_T eep04wvcnw_idx_2 ; real32_T b5osnmhsrd_idx_1
; real32_T b5osnmhsrd_idx_2 ; real32_T osbuvwrg2r_idx_1 ; real32_T
eep04wvcnw_idx_0 ; real32_T osbuvwrg2r_idx_0 ; real32_T eep04wvcnw_idx_1 ;
real32_T osbuvwrg2r_idx_2 ; real32_T oxxshm0p0o_idx_1 ; real32_T
oxxshm0p0o_idx_2 ; real32_T b5vwzreuo4_idx_0 ; real32_T b5vwzreuo4_idx_1 ;
real32_T kgtfcegdc5_idx_1 ; real32_T pyvm2ihwbp_idx_2 ; real32_T
pyvm2ihwbp_idx_1 ; real32_T kgtfcegdc5_idx_2 ; real32_T h4jvvstx1t_idx_1 ;
real32_T h4jvvstx1t_idx_0 ; int32_T denIdx ; int32_T uIdx ; int32_T cff ;
int32_T nz ; int32_T i ; uint32_T nir2sesw4o ; uint32_T gfrwlpjnn2 ; uint32_T
fpekvbmxwa ; real32_T djn3bbsoat [ 6 ] ; real32_T p5pzfnaiuu [ 2 ] ; real32_T
octkfvursp [ 3 ] ; real32_T enwpjq4sny [ 3 ] ; real32_T kitmhlyutx [ 2 ] ;
real32_T i53pibnrls [ 2 ] ; real32_T jl4zglnkcz [ 2 ] ; real32_T k1lgyzog01 [
2 ] ; real32_T cdicpgn145 ; real32_T dz0gwbmcjt [ 4 ] ; real32_T bbwy42xxao [
2 ] ; real32_T ee2t4z12sj [ 2 ] ; real32_T kynsre5lf4 [ 3 ] ; real32_T
a1bbiq2a3a [ 16 ] ; real32_T oaczprok10 [ 4 ] ; real32_T kyi2cghtbd [ 4 ] ;
real32_T b5osnmhsrd [ 2 ] ; real32_T bkehspj2gn [ 2 ] ; real32_T cfcvjoerpa [
2 ] ; uint8_T i0mkwvniar ; boolean_T kxhectt5uh ; boolean_T c0bmzndvwn ;
boolean_T ewcvsl00tt ; boolean_T f25x251bac ; } eo4bbte2ey ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real_T mck2owxrk2 ; real_T etwz51o21c [ 2 ] ; real_T
c4t5e3w5ek [ 3 ] ; real_T hmetbef2mf ; real_T me4j0lrjd2 ; real_T mb3yoxlyu3
; real_T bw2ribqmwm ; real_T fl2edockfe ; struct { void * LoggedData ; void *
SignalProbe ; } mpopad3fr1 ; real32_T jxg1zvdttz [ 2 ] ; real32_T kgows215bs
[ 3 ] ; real32_T liybiw1jbg [ 5 ] ; real32_T nbbc5odoq4 [ 15 ] ; real32_T
kzeijhdtif [ 2 ] ; real32_T heeedoxzle [ 10 ] ; real32_T gqxdiwstsm [ 2 ] ;
real32_T a3uar2xrsb [ 2 ] ; real32_T lw3rw5s0ye [ 2 ] ; real32_T cosb2ibhn3 [
2 ] ; real32_T fuo05buemm [ 2 ] ; real32_T ppp4ajc3p1 ; int32_T cfcgwprtdx ;
uint32_T npsllq52wf ; uint32_T i13qoukcsn ; uint32_T dxm3w2i52x ; real32_T
ik5zcuhoy3 ; real32_T lfi3mnae2m [ 3 ] ; real32_T lpva1qajzk ; real32_T
dhhdwwczx2 [ 2 ] ; int8_T ii2o5s5qnf ; int8_T gafzug4yea ; int8_T nuogwfijir
; int8_T hihnlferdi ; int8_T pxamy50saq ; int8_T btfjf5acqg ; int8_T
oa1muqt4on ; int8_T h0cudiu0ft ; int8_T iu11iwpdyn ; int8_T b3ewiobpsi ;
uint8_T ozjz0fr0k4 ; uint8_T pvn1aiza5a ; boolean_T j20mj4ai3a ; boolean_T
bgpppixzwr ; boolean_T cmab1dak24 ; boolean_T jtnjtissuf ; hrtts4l5bc
ciy1c2o0rv ; hrtts4l5bc jvbbqhrajh ; hrtts4l5bc clwiujjdqo ; hrtts4l5bc
acfz1zxm4t ; hrtts4l5bc ghadbep3bbv ; } dmp1xsadgu ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { uint8_T b_varargout_3 [ 19200 ] ; uint8_T b_varargout_2 [
19200 ] ; uint8_T b_varargout_1 [ 19200 ] ; boolean_T jr5xpaibtu_mbvzarwird [
19200 ] ; boolean_T chvqnltnss_cl54gopm0x [ 19200 ] ; int32_T i ; int32_T i1
; eo4bbte2ey otjykwnhb3s ; } ircitwx3zdm ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { bjqsgn0csy l152eirbdu ; int8_T fb0f52aifb ; boolean_T
oq44mkeutp [ 38400 ] ; boolean_T jjrfotind4 ; dmp1xsadgu otjykwnhb3s ; }
nllkaxiwhzw ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct bpvdgm2xq5_ { uint8_T P_0 ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct nu4qaxumex_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; real_T P_5 ; real32_T P_6 ; real32_T P_7 ; real32_T P_8 ;
real32_T P_9 ; real32_T P_10 ; real32_T P_11 ; real32_T P_12 ; real32_T P_13
; real32_T P_14 ; real32_T P_15 ; real32_T P_16 ; real32_T P_17 ; real32_T
P_18 ; real32_T P_19 ; real32_T P_20 ; real32_T P_21 ; real32_T P_22 ;
real32_T P_23 ; real32_T P_24 ; real32_T P_25 ; real32_T P_26 ; real32_T P_27
; real32_T P_28 ; uint32_T P_29 ; uint32_T P_30 ; uint32_T P_31 ; uint32_T
P_32 ; uint32_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37
; real_T P_38 [ 4 ] ; real_T P_39 [ 4 ] ; real_T P_40 ; real_T P_41 ; real_T
P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ;
real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T
P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 [ 4 ] ; real_T P_57 [ 2 ] ;
real_T P_58 [ 2 ] ; real_T P_59 [ 4 ] ; real_T P_60 [ 2 ] ; real_T P_61 [ 2 ]
; real_T P_62 ; real_T P_63 [ 4 ] ; real_T P_64 [ 2 ] ; real_T P_65 ; real_T
P_66 ; real_T P_67 ; real_T P_68 ; real_T P_69 [ 2 ] ; real_T P_70 [ 3 ] ;
real_T P_71 [ 3 ] ; real_T P_72 [ 4 ] ; real_T P_73 [ 4 ] ; real_T P_74 [ 4 ]
; real32_T P_75 [ 2 ] ; real32_T P_76 ; real32_T P_77 ; real32_T P_78 ;
real32_T P_79 [ 2 ] ; real32_T P_80 ; real32_T P_81 ; real32_T P_82 ;
real32_T P_83 ; real32_T P_84 ; real32_T P_85 ; real32_T P_86 ; real32_T P_87
; real32_T P_88 ; real32_T P_89 ; real32_T P_90 ; real32_T P_91 ; real32_T
P_92 ; real32_T P_93 ; real32_T P_94 ; real32_T P_95 ; real32_T P_96 [ 4 ] ;
real32_T P_97 [ 4 ] ; real32_T P_98 ; real32_T P_99 [ 3 ] ; real32_T P_100 ;
real32_T P_101 [ 6 ] ; real32_T P_102 [ 6 ] ; real32_T P_103 [ 6 ] ; real32_T
P_104 [ 6 ] ; real32_T P_105 ; real32_T P_106 ; real32_T P_107 ; real32_T
P_108 [ 6 ] ; real32_T P_109 ; real32_T P_110 [ 6 ] ; real32_T P_111 [ 6 ] ;
real32_T P_112 ; real32_T P_113 ; real32_T P_114 ; real32_T P_115 ; real32_T
P_116 ; real32_T P_117 ; real32_T P_118 [ 2 ] ; real32_T P_119 ; real32_T
P_120 ; real32_T P_121 ; real32_T P_122 ; real32_T P_123 ; real32_T P_124 [ 2
] ; real32_T P_125 ; real32_T P_126 ; real32_T P_127 ; real32_T P_128 ;
real32_T P_129 ; real32_T P_130 ; real32_T P_131 ; real32_T P_132 ; real32_T
P_133 ; real32_T P_134 ; real32_T P_135 ; real32_T P_136 ; real32_T P_137 ;
real32_T P_138 [ 4 ] ; real32_T P_139 ; real32_T P_140 ; real32_T P_141 ;
real32_T P_142 [ 16 ] ; real32_T P_143 ; real32_T P_144 ; real32_T P_145 ;
real32_T P_146 [ 4 ] ; real32_T P_147 [ 4 ] ; real32_T P_148 [ 4 ] ; real32_T
P_149 [ 4 ] ; real32_T P_150 [ 4 ] ; real32_T P_151 [ 4 ] ; real32_T P_152 [
4 ] ; real32_T P_153 [ 4 ] ; real32_T P_154 [ 4 ] ; real32_T P_155 [ 4 ] ;
real32_T P_156 [ 2 ] ; uint32_T P_157 ; uint32_T P_158 ; uint32_T P_159 ;
uint32_T P_160 ; uint32_T P_161 ; uint32_T P_162 ; uint32_T P_163 ; uint32_T
P_164 ; uint32_T P_165 ; boolean_T P_166 ; boolean_T P_167 ; uint8_T P_168 ;
bpvdgm2xq5 ciy1c2o0rv ; bpvdgm2xq5 jvbbqhrajh ; bpvdgm2xq5 clwiujjdqo ;
bpvdgm2xq5 acfz1zxm4t ; bpvdgm2xq5 ghadbep3bbv ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct ileg2v2ld1r_ { boolean_T P_1 ; nu4qaxumex otjykwnhb3s ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct diqjpw4041 { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 23 ] ; int32_T * vardimsAddress [
23 ] ; RTWLoggingFcnPtr loggingPtrs [ 23 ] ; sysRanDType * systemRan [ 28 ] ;
int_T systemTid [ 28 ] ; } DataMapInfo ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { ipf5ube4r0 rtm ; } lhjbdsj2rjg ;
#endif
extern struct_8SSZ93PxvPkADZcA4gG8MD rtP_Sensors ; extern void ha1ipjbq54 (
uint8_T * o3vpgniqky ) ; extern void gwlyno50ln ( void ) ; extern void
k3yxem35zg ( void ) ; extern void bog0frvixl ( void ) ; extern void
pyvd4pdf3iTID0 ( void ) ; extern void pyvd4pdf3iTID1 ( void ) ; extern void
pyvd4pdf3iTID2 ( void ) ; extern void flightControlSystemTID0 ( const
CommandBus * iarztl0jur , const SensorsBus * pxdb2gu5va , real32_T pikqq4svts
[ 4 ] , uint8_T * o3vpgniqky ) ; extern void flightControlSystemTID1 ( void )
; extern void flightControlSystemTID2 ( void ) ; extern void o2f5l50guo (
void ) ; extern void f4qzdbbxmw ( SimStruct * _mdlRefSfcnS , int_T
mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 , void * sysRanPtr , int
contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_flightControlSystem_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray *
mr_flightControlSystem_GetDWork ( ) ; extern void
mr_flightControlSystem_SetDWork ( const mxArray * ssDW ) ; extern void
mr_flightControlSystem_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_flightControlSystem_GetSimStateDisallowedBlocks ( ) ; extern
const rtwCAPI_ModelMappingStaticInfo * flightControlSystem_GetCAPIStaticMap (
void ) ;
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern void ghadbep3bb ( uint8_T * hfpztkhwej , bpvdgm2xq5 * localP ) ;
extern void ic5jb3movn ( eo4bbte2ey * localB , dmp1xsadgu * localDW ,
nu4qaxumex * localP ) ; extern void bxsrqc204k ( dmp1xsadgu * localDW ,
nu4qaxumex * localP ) ; extern void kegjp2lgms ( eo4bbte2ey * localB ,
dmp1xsadgu * localDW , nu4qaxumex * localP ) ; extern void lsjhvu4egy (
eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP ) ; extern
void otjykwnhb3 ( ipf5ube4r0 * const accn4cnket , const CommandBus *
ipxpc4eli1 , const SensorsBus * fp0u5nlpgw , const boolean_T ay1xsyaztb [
19200 ] , eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP )
; extern void otjykwnhb3TID2 ( eo4bbte2ey * localB , nu4qaxumex * localP ) ;
#endif
void mr_flightControlSystem_CreateInitRestoreData ( ) ; void
mr_flightControlSystem_CopyFromInitRestoreData ( ) ; void
mr_flightControlSystem_DestroyInitRestoreData ( ) ;
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern lhjbdsj2rjg lhjbdsj2rj ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern ircitwx3zdm ksm0js2nhsy ; extern nllkaxiwhzw dqykr4eggmg ;
#endif
#endif
