#ifndef RTW_HEADER_flightControlSystem_capi_h_
#define RTW_HEADER_flightControlSystem_capi_h_
#include "flightControlSystem.h"
extern void flightControlSystem_InitializeDataMapInfo ( ipf5ube4r0 * const
accn4cnket , void * sysRanPtr , int contextTid ) ;
#endif
