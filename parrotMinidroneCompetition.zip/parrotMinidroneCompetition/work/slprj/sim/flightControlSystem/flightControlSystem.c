#include "flightControlSystem_capi.h"
#include "flightControlSystem.h"
#include "flightControlSystem_private.h"
#include "mod_L9P39Tyf.h"
#include "ndgrid_RnXP2lml.h"
int_T nmtwkzsqud [ 3 ] ; static RegMdlInfo rtMdlInfo_flightControlSystem [
133 ] = { { "ezsua5bijx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "flightControlSystem" } , { "omkirkweac" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lrsxga1mux" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "edl35owv4q" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "jig1nknlld" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "npn1dfesfs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "iffergcei1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "bsr3dujuk0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "crxyn1tssm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "lwj4qypsny" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "bpvdgm2xq5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "hrtts4l5bc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "mqmoncitu3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "k5baggiqtb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ei3m5g1hta" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "hn4i3fu15a" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "lbu5phzg3y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "mtaqz0ggi1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "mfdtth4fkl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "cn2vepzj0w" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "dfqhc4tws4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ph1mky0ofs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "femqyyfyjs" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nu4qaxumex" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "dmp1xsadgu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "eo4bbte2ey" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lhjbdsj2rjg" , MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * )
"flightControlSystem" } , { "lhjbdsj2rj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "h5liyesltnn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "k0lgy5kzmig" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "d2rcqsbpxyc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "kekotmnbk54" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "no25hyfktuo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ht3wudfgy2u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "iesycof4wox" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "eev4eat4b5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "cspyln32yuv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "dhuzh5wmni3" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "b1hr2q0zjhm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "nllkaxiwhzw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "ircitwx3zdm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "h5liyesltn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "k0lgy5kzmi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "d2rcqsbpxy" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "kekotmnbk5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "no25hyfktu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ht3wudfgy2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "iesycof4wo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "cspyln32yu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "dhuzh5wmni" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "b1hr2q0zjh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "nllkaxiwhz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ircitwx3zd" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "b42rzqdx01" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "o2f5l50guo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "m0l5se3ogg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "bog0frvixl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "o5hyd2bjrc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "pyvd4pdf3i" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "gwlyno50ln" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ha1ipjbq54" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "f4qzdbbxmw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "k3yxem35zg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "dw0zngvhyq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "o0d2t1xos2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "oplbkbi520" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "eyt3piuhqz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "kegjp2lgms" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nwvibpjmp0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "lsjhvu4egy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "bxsrqc204k" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ic5jb3movn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "n4xf3lkvmk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "cyp5v4ller" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "mr51bswvyz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "otjykwnhb3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , 0 , ( void * ) "Control System" } , { "itmfjpgv1o" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "dychmi5jvf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "okzguhbnst" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "gjrgypdhn2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nsvs5ni5i5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "b5nnaqep53" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ghadbep3bb" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * ) "Geofencing error" } ,
{ "flightControlSystem" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL )
} , { "d0ohl2eoh0m" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "nmtwkzsqud" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "dqykr4eggmg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ksm0js2nhsy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "diqjpw4041" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ipf5ube4r0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "parrot_ImageProcess1" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } ,
{ "struct_OSJpyIZcrpXqReVWwh9iuG" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL
) } , { "struct_p3FXZIgqtjF2uqDpmYjb6C" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_OMRgDnJcZuQneKEj9vdTyD" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "struct_q6UUpnZ4gTjFvULFx6Rxa" , MDL_INFO_ID_DATA_TYPE , 0
, - 1 , ( NULL ) } , { "struct_IZWOW0zYvpphl7qLgSfN7E" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_hxsmtt0xTZOLDNa2Rz7GAF" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_XRMsui9C07VjBvdq1msujB" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_eAf0NJvzCY9HYTXF7bLNgB" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "SensorsBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "HAL_acquisition_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_vbat_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_ultrasound_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_list_echo_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_echo_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_pressure_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_magn_mG_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_fifo_gyro_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_gyro_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"HAL_acc_SI_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"extraSensorData_t" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"CommandBus" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_S5XPVZr9Ltni4p5tjvWJ6C" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_8SSZ93PxvPkADZcA4gG8MD" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_eFnp8sKFNJLN84XLbLzaFF" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "struct_FIfaVnupBjYAxo1EdNiDlF" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_eF5OUT33sX0T9pzS8027m" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_X1tFsdWsY5fUn8DhZV5x2G" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_hE1099BMemg5OfzqcWAA6G" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "mr_flightControlSystem_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "flightControlSystem" } , { "mr_flightControlSystem_GetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"flightControlSystem.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"flightControlSystem.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"flightControlSystem" } } ; ileg2v2ld1r b1hr2q0zjh = { 0 , { 50.0 , - 1.0 ,
0.8 , 0.4 , 0.1 , 0.0 , 0.0F , 10.0F , 10.0F , 6.0F , 6.0F , 0.01F , 0.01F ,
9.79038F , 9.82962F , - 0.4F , 0.0F , 0.0F , 80.0F , 80.0F , 0.6F , 0.5F ,
0.6F , 0.5F , 7.0F , 7.0F , 5.0F , 5.0F , - 0.4F , 4294967295U , 4294967295U
, 4294967295U , 100U , 800U , 0.0 , 0.0 , 0.0 , 0.0 , { 3.7568380197861018E-6
, 1.1270514059358305E-5 , 1.1270514059358305E-5 , 3.7568380197861018E-6 } , {
1.0 , - 2.9371707284498907 , 2.8762997234793319 , - 0.939098940325283 } , 0.0
, 0.0 , 0.017453292519943295 , 0.0 , - 1.0 , 0.0 , 0.0 , 0.2 , 0.0 , 0.5 ,
600.0 , 0.0006 , 360.0 , 15.0 , 140.0 , - 1.1 , { 1.0 , 0.0 , 0.005 , 1.0 } ,
{ 0.0 , 0.005 } , { 1.0 , 0.0 } , { 0.0026241420641871633 ,
0.0069776736071491688 , 0.0069776736071491688 , 0.037607692935055337 } , {
0.026590304322229058 , 0.06977673607149236 } , { 0.02624142064187163 ,
0.0697767360714917 } , 0.0 , { 0.0026948589925820388 , 0.0071657120718244521
, 0.0071657120718244521 , 0.03810769293505533 } , { 0.0 , 1.0 } , 0.0 , 0.0 ,
0.0005 , 0.1 , { - 0.046 , 0.0 } , { 0.0 , 0.0 , 9.81 } , { 0.0 , 0.0 , -
9.81 } , { 0.62732804493044869 , 0.0 , 0.0 , 0.62732804493044869 } , {
0.12546560898608977 , 0.0 , 0.0 , 0.12546560898608977 } , {
0.12546560898608972 , 0.0 , 0.0 , 0.12546560898608972 } , { 0.1F , - 0.1F } ,
- 1.0F , 3.0F , - 3.0F , { - 0.15F , 0.15F } , 0.5F , 0.8F , 0.45F , 0.999F ,
0.001F , 0.101936802F , 0.001F , 0.999F , - 1.0F , 1.15F , 0.0F , 0.0F ,
0.005F , 0.0F , - 1.0F , 0.0832137167F , { 3.75683794E-6F , 1.12705138E-5F ,
1.12705138E-5F , 3.75683794E-6F } , { 1.0F , - 2.93717074F , 2.87629962F , -
0.939098954F } , 0.0F , { 0.0F , 0.0F , 0.0F } , - 1.0F , { 0.0F , 0.0F ,
9.81F , 0.0F , 0.0F , 0.0F } , { 0.994075298F , 0.996184587F , 1.00549F ,
1.00139189F , 0.993601203F , 1.00003F } , { 0.282124132F , 1.27253926F ,
2.42084408F , 2.42084408F , 1.27253926F , 0.282124132F } , { 1.0F ,
2.22871494F , 2.52446198F , 1.57725322F , 0.54102242F , 0.0795623958F } ,
0.0F , 0.005F , 0.0F , { 0.0264077242F , 0.140531361F , 0.33306092F ,
0.33306092F , 0.140531361F , 0.0264077242F } , 0.0F , { 0.282124132F ,
1.27253926F , 2.42084408F , 2.42084408F , 1.27253926F , 0.282124132F } , {
1.0F , 2.22871494F , 2.52446198F , 1.57725322F , 0.54102242F , 0.0795623958F
} , 0.0F , 200.0F , 0.0F , 0.0F , 0.0F , 0.001F , { 0.002F , 0.003F } ,
0.005F , 0.0F , 2.0F , - 2.0F , 0.01F , { 0.013F , 0.011F } , - 0.61803F ,
0.005F , 0.0F , 2.0F , - 2.0F , 1.20204329F , - 1.20204329F , 0.004F ,
0.0012F , 0.24F , - 1530.72681F , 500.0F , 10.0F , { 1.0F , - 1.0F , 1.0F , -
1.0F } , 1.0F , 1.0F , 0.002F , { 0.25F , 0.25F , 0.25F , 0.25F , 103.573624F
, - 103.573624F , 103.573624F , - 103.573624F , - 5.66592F , - 5.66592F ,
5.66592F , 5.66592F , - 5.66592F , 5.66592F , 5.66592F , - 5.66592F } , 0.0F
, 2.0F , 0.0F , { 1.0F , 0.0F , 0.0F , 1.0F } , { 0.005F , 0.0F , 0.0F ,
0.005F } , { 1.0F , 0.0F , 0.0F , 1.0F } , { 0.0F , 0.0F , 0.0F , 0.0F } , {
0.717328072F , - 0.0F , - 0.0F , 0.717328072F } , { 1.0F , 0.0F , 0.0F , 1.0F
} , { 0.0F , 0.0F , 0.0F , 0.0F } , { 0.0F , 0.0F , 0.0F , 0.0F } , { 0.09F ,
0.0F , 0.0F , 0.09F } , { 5.0F , 0.0F , 0.0F , 5.0F } , { 0.0F , 0.0F } , 0U
, 0U , 0U , 1U , 0U , 1U , 0U , 1U , 0U , 1 , 1 , 0U , { 0U } , { 0U } , { 0U
} , { 99U } , { 1U } } } ; lhjbdsj2rjg lhjbdsj2rj ; ircitwx3zdm ksm0js2nhsy ;
nllkaxiwhzw dqykr4eggmg ; static void l5fvh44l1b ( const real_T x_data [ ] ,
const int32_T x_size [ 2 ] , real_T y [ 2 ] ) ; static boolean_T e4uq03sdk2 (
bjqsgn0csy * obj ) ; static void llg2sedmqv ( uint8_T varargout_1 [ 19200 ] ,
uint8_T varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) ; static void
bljpfp3pka ( bjqsgn0csy * obj , uint8_T varargout_1 [ 19200 ] , uint8_T
varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) ; void ghadbep3bb (
uint8_T * hfpztkhwej , bpvdgm2xq5 * localP ) { * hfpztkhwej = localP -> P_0 ;
} static void l5fvh44l1b ( const real_T x_data [ ] , const int32_T x_size [ 2
] , real_T y [ 2 ] ) { int32_T k ; if ( x_size [ 0 ] == 0 ) { y [ 0 ] = 0.0 ;
y [ 1 ] = 0.0 ; } else { y [ 0 ] = x_data [ 0 ] ; for ( k = 2 ; k <= x_size [
0 ] ; k ++ ) { y [ 0 ] += x_data [ k - 1 ] ; } y [ 1 ] = x_data [ x_size [ 0
] ] ; for ( k = 2 ; k <= x_size [ 0 ] ; k ++ ) { y [ 1 ] += x_data [ ( x_size
[ 0 ] + k ) - 1 ] ; } } y [ 0 ] /= ( real_T ) x_size [ 0 ] ; y [ 1 ] /= (
real_T ) x_size [ 0 ] ; } void ic5jb3movn ( eo4bbte2ey * localB , dmp1xsadgu
* localDW , nu4qaxumex * localP ) { int32_T i ; localDW -> jxg1zvdttz [ 0 ] =
localP -> P_93 ; localDW -> jxg1zvdttz [ 1 ] = localP -> P_93 ; localDW ->
ii2o5s5qnf = 2 ; localDW -> mck2owxrk2 = localP -> P_36 ; localDW ->
ozjz0fr0k4 = 1U ; localDW -> kgows215bs [ 0 ] = localP -> P_98 ; localDW ->
c4t5e3w5ek [ 0 ] = localP -> P_40 ; localDW -> lfi3mnae2m [ 0 ] = localP ->
P_99 [ 0 ] ; localDW -> kgows215bs [ 1 ] = localP -> P_98 ; localDW ->
c4t5e3w5ek [ 1 ] = localP -> P_40 ; localDW -> lfi3mnae2m [ 1 ] = localP ->
P_99 [ 1 ] ; localDW -> kgows215bs [ 2 ] = localP -> P_98 ; localDW ->
c4t5e3w5ek [ 2 ] = localP -> P_40 ; localDW -> lfi3mnae2m [ 2 ] = localP ->
P_99 [ 2 ] ; for ( i = 0 ; i < 5 ; i ++ ) { localDW -> liybiw1jbg [ i ] =
localP -> P_105 ; } localDW -> cfcgwprtdx = 0 ; for ( i = 0 ; i < 15 ; i ++ )
{ localDW -> nbbc5odoq4 [ i ] = localP -> P_107 ; } localDW -> npsllq52wf =
localP -> P_157 ; localDW -> pvn1aiza5a = 1U ; for ( i = 0 ; i < 10 ; i ++ )
{ localDW -> heeedoxzle [ i ] = localP -> P_112 ; } localDW -> hmetbef2mf =
localP -> P_41 ; localDW -> me4j0lrjd2 = localP -> P_43 ; localDW ->
mb3yoxlyu3 = localP -> P_45 ; localDW -> gqxdiwstsm [ 0 ] = localP -> P_6 ;
localDW -> a3uar2xrsb [ 0 ] = localP -> P_114 ; localDW -> lw3rw5s0ye [ 0 ] =
localP -> P_115 ; localDW -> cosb2ibhn3 [ 0 ] = localP -> P_116 ; localDW ->
fuo05buemm [ 0 ] = localP -> P_120 ; localDW -> gqxdiwstsm [ 1 ] = localP ->
P_6 ; localDW -> a3uar2xrsb [ 1 ] = localP -> P_114 ; localDW -> lw3rw5s0ye [
1 ] = localP -> P_115 ; localDW -> cosb2ibhn3 [ 1 ] = localP -> P_116 ;
localDW -> fuo05buemm [ 1 ] = localP -> P_120 ; localDW -> i13qoukcsn =
localP -> P_158 ; localDW -> ppp4ajc3p1 = localP -> P_127 ; localDW ->
gafzug4yea = 2 ; localDW -> dxm3w2i52x = localP -> P_159 ; localDW ->
bw2ribqmwm = localP -> P_46 ; localB -> i0mkwvniar = localP -> P_168 ; localB
-> p5pzfnaiuu [ 0 ] = localP -> P_109 ; localB -> j42uqprebt [ 0 ] = localP
-> P_34 ; localB -> ozbnyngphj [ 0 ] = localP -> P_35 ; localB -> cfcvjoerpa
[ 0 ] = localP -> P_90 ; localB -> bkehspj2gn [ 0 ] = localP -> P_91 ; localB
-> p5pzfnaiuu [ 1 ] = localP -> P_109 ; localB -> j42uqprebt [ 1 ] = localP
-> P_34 ; localB -> ozbnyngphj [ 1 ] = localP -> P_35 ; localB -> cfcvjoerpa
[ 1 ] = localP -> P_90 ; localB -> bkehspj2gn [ 1 ] = localP -> P_91 ; } void
bxsrqc204k ( dmp1xsadgu * localDW , nu4qaxumex * localP ) { int32_T i ;
localDW -> jxg1zvdttz [ 0 ] = localP -> P_93 ; localDW -> jxg1zvdttz [ 1 ] =
localP -> P_93 ; localDW -> ii2o5s5qnf = 2 ; localDW -> mck2owxrk2 = localP
-> P_36 ; localDW -> ozjz0fr0k4 = 1U ; localDW -> kgows215bs [ 0 ] = localP
-> P_98 ; localDW -> c4t5e3w5ek [ 0 ] = localP -> P_40 ; localDW ->
lfi3mnae2m [ 0 ] = localP -> P_99 [ 0 ] ; localDW -> kgows215bs [ 1 ] =
localP -> P_98 ; localDW -> c4t5e3w5ek [ 1 ] = localP -> P_40 ; localDW ->
lfi3mnae2m [ 1 ] = localP -> P_99 [ 1 ] ; localDW -> kgows215bs [ 2 ] =
localP -> P_98 ; localDW -> c4t5e3w5ek [ 2 ] = localP -> P_40 ; localDW ->
lfi3mnae2m [ 2 ] = localP -> P_99 [ 2 ] ; for ( i = 0 ; i < 5 ; i ++ ) {
localDW -> liybiw1jbg [ i ] = localP -> P_105 ; } localDW -> cfcgwprtdx = 0 ;
for ( i = 0 ; i < 15 ; i ++ ) { localDW -> nbbc5odoq4 [ i ] = localP -> P_107
; } localDW -> npsllq52wf = localP -> P_157 ; localDW -> pvn1aiza5a = 1U ;
for ( i = 0 ; i < 10 ; i ++ ) { localDW -> heeedoxzle [ i ] = localP -> P_112
; } localDW -> hmetbef2mf = localP -> P_41 ; localDW -> me4j0lrjd2 = localP
-> P_43 ; localDW -> mb3yoxlyu3 = localP -> P_45 ; localDW -> gqxdiwstsm [ 0
] = localP -> P_6 ; localDW -> a3uar2xrsb [ 0 ] = localP -> P_114 ; localDW
-> lw3rw5s0ye [ 0 ] = localP -> P_115 ; localDW -> cosb2ibhn3 [ 0 ] = localP
-> P_116 ; localDW -> fuo05buemm [ 0 ] = localP -> P_120 ; localDW ->
gqxdiwstsm [ 1 ] = localP -> P_6 ; localDW -> a3uar2xrsb [ 1 ] = localP ->
P_114 ; localDW -> lw3rw5s0ye [ 1 ] = localP -> P_115 ; localDW -> cosb2ibhn3
[ 1 ] = localP -> P_116 ; localDW -> fuo05buemm [ 1 ] = localP -> P_120 ;
localDW -> i13qoukcsn = localP -> P_158 ; localDW -> ppp4ajc3p1 = localP ->
P_127 ; localDW -> gafzug4yea = 2 ; localDW -> dxm3w2i52x = localP -> P_159 ;
localDW -> bw2ribqmwm = localP -> P_46 ; } void kegjp2lgms ( eo4bbte2ey *
localB , dmp1xsadgu * localDW , nu4qaxumex * localP ) { if ( localDW ->
jtnjtissuf ) { localB -> j42uqprebt [ 0 ] = localP -> P_34 ; localB ->
j42uqprebt [ 1 ] = localP -> P_34 ; localDW -> jtnjtissuf = false ; } if (
localDW -> cmab1dak24 ) { localB -> ozbnyngphj [ 0 ] = localP -> P_35 ;
localB -> ozbnyngphj [ 1 ] = localP -> P_35 ; localDW -> cmab1dak24 = false ;
} if ( localDW -> bgpppixzwr ) { localB -> cfcvjoerpa [ 0 ] = localP -> P_90
; localB -> cfcvjoerpa [ 1 ] = localP -> P_90 ; localDW -> bgpppixzwr = false
; } if ( localDW -> j20mj4ai3a ) { localB -> bkehspj2gn [ 0 ] = localP ->
P_91 ; localB -> bkehspj2gn [ 1 ] = localP -> P_91 ; localDW -> j20mj4ai3a =
false ; } } void otjykwnhb3 ( ipf5ube4r0 * const accn4cnket , const
CommandBus * ipxpc4eli1 , const SensorsBus * fp0u5nlpgw , const boolean_T
ay1xsyaztb [ 19200 ] , eo4bbte2ey * localB , dmp1xsadgu * localDW ,
nu4qaxumex * localP ) { uint32_T de3g0eec4m ; uint32_T ctv5xw2mss ; uint32_T
bhjzwuyxdg ; uint32_T f1qxkoe3mf ; uint32_T katpqstrxz ; uint32_T bzay4rc4o2
; boolean_T jdm0cqmgmv ; boolean_T ogybdje05f ; boolean_T ig4cpcv0zy ;
boolean_T byi5lgnzr5 ; boolean_T lq42vmb0rf ; boolean_T hjdzwdsemb ;
boolean_T dk05t4kqcv ; real32_T ks0vnqom2i_idx_2 ; real32_T ks0vnqom2i_idx_1
; real32_T h4jvvstx1t_idx_2 ; int8_T vector_idx_0 ; int8_T vector_idx_1 ;
real32_T fggzgj03gr_idx_1 ; if ( localP -> P_167 && ( localDW -> ii2o5s5qnf
<= 0 ) ) { localDW -> jxg1zvdttz [ 0 ] = localP -> P_93 ; localDW ->
jxg1zvdttz [ 1 ] = localP -> P_93 ; } localB -> b5vwzreuo4_idx_0 = localDW ->
jxg1zvdttz [ 0 ] ; localB -> b5vwzreuo4_idx_1 = localDW -> jxg1zvdttz [ 1 ] ;
localB -> bnbzowcxmh = ( real_T ) localP -> P_94 * fp0u5nlpgw -> HALSensors .
HAL_ultrasound_SI . altitude ; localB -> a1bbiq2a3a_merlcviukg = localB ->
bnbzowcxmh ; localB -> kxhectt5uh = ( localDW -> mck2owxrk2 > localP -> P_5 )
; if ( localB -> kxhectt5uh ) { localDW -> ozjz0fr0k4 = 1U ; } if ( localDW
-> ozjz0fr0k4 != 0 ) { localDW -> etwz51o21c [ 0 ] = localB -> fnzhxbxjia [ 0
] ; localDW -> etwz51o21c [ 1 ] = localB -> fnzhxbxjia [ 1 ] ; } localB ->
in00o5ix5a_idx_0 = localDW -> etwz51o21c [ 0 ] ; localB -> in00o5ix5a_idx_1 =
localDW -> etwz51o21c [ 1 ] ; localDW -> ik5zcuhoy3 = ( ( ( ( fp0u5nlpgw ->
HALSensors . HAL_pressure_SI . pressure - fp0u5nlpgw -> SensorCalibration [ 6
] ) * localP -> P_95 - localP -> P_97 [ 1 ] * localDW -> kgows215bs [ 0 ] ) -
localP -> P_97 [ 2 ] * localDW -> kgows215bs [ 1 ] ) - localP -> P_97 [ 3 ] *
localDW -> kgows215bs [ 2 ] ) / localP -> P_97 [ 0 ] ; localB ->
hrsldhjj3q_dhamdvybc1 = ( ( localP -> P_96 [ 0 ] * localDW -> ik5zcuhoy3 +
localP -> P_96 [ 1 ] * localDW -> kgows215bs [ 0 ] ) + localP -> P_96 [ 2 ] *
localDW -> kgows215bs [ 1 ] ) + localP -> P_96 [ 3 ] * localDW -> kgows215bs
[ 2 ] ; localDW -> fl2edockfe = ( ( ( localB -> bnbzowcxmh - localP -> P_39 [
1 ] * localDW -> c4t5e3w5ek [ 0 ] ) - localP -> P_39 [ 2 ] * localDW ->
c4t5e3w5ek [ 1 ] ) - localP -> P_39 [ 3 ] * localDW -> c4t5e3w5ek [ 2 ] ) /
localP -> P_39 [ 0 ] ; if ( localB -> bnbzowcxmh > - rtP_Sensors .
altSensorMin ) { localB -> c01pvjzgld_nz4o0shxby = - rtP_Sensors .
altSensorMin ; } else if ( localB -> bnbzowcxmh < localP -> P_37 ) { localB
-> c01pvjzgld_nz4o0shxby = localP -> P_37 ; } else { localB ->
c01pvjzgld_nz4o0shxby = localB -> bnbzowcxmh ; } localB -> c0bmzndvwn = ( (
muDoubleScalarAbs ( localDW -> mck2owxrk2 - localB -> c01pvjzgld_nz4o0shxby )
<= localP -> P_4 ) && ( localB -> bnbzowcxmh < - rtP_Sensors . altSensorMin )
&& ( ( ! ( muDoubleScalarAbs ( localB -> hrsldhjj3q_dhamdvybc1 - localDW ->
mck2owxrk2 ) >= localP -> P_2 ) ) || ( ! ( muDoubleScalarAbs ( ( ( ( localP
-> P_38 [ 0 ] * localDW -> fl2edockfe + localP -> P_38 [ 1 ] * localDW ->
c4t5e3w5ek [ 0 ] ) + localP -> P_38 [ 2 ] * localDW -> c4t5e3w5ek [ 1 ] ) +
localP -> P_38 [ 3 ] * localDW -> c4t5e3w5ek [ 2 ] ) - localDW -> mck2owxrk2
) >= localP -> P_3 ) ) ) ) ; hjdzwdsemb = localB -> c0bmzndvwn ; jdm0cqmgmv =
localB -> c0bmzndvwn ; if ( jdm0cqmgmv ) { if ( ! localDW -> cmab1dak24 ) {
if ( rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> cmab1dak24 = true ; } localB -> c01pvjzgld_nz4o0shxby = localB ->
a1bbiq2a3a_merlcviukg - ( localP -> P_58 [ 0 ] * localB -> in00o5ix5a_idx_0 +
localP -> P_58 [ 1 ] * localB -> in00o5ix5a_idx_1 ) ; localB -> ozbnyngphj [
0 ] = localB -> lxqvlboqdo [ 0 ] * localB -> c01pvjzgld_nz4o0shxby ; localB
-> ozbnyngphj [ 1 ] = localB -> lxqvlboqdo [ 1 ] * localB ->
c01pvjzgld_nz4o0shxby ; srUpdateBC ( localDW -> pxamy50saq ) ; } else { if (
localDW -> cmab1dak24 ) { ssSetBlockStateForSolverChangedAtMajorStep (
accn4cnket -> _mdlRefSfcnS ) ; localB -> ozbnyngphj [ 0 ] = localP -> P_35 ;
localB -> ozbnyngphj [ 1 ] = localP -> P_35 ; localDW -> cmab1dak24 = false ;
} } localB -> ernp5tvitp [ 0 ] = localB -> ozbnyngphj [ 0 ] + localB ->
in00o5ix5a_idx_0 ; localB -> ernp5tvitp [ 1 ] = localB -> ozbnyngphj [ 1 ] +
localB -> in00o5ix5a_idx_1 ; localB -> ceqpqrxfmi_ldqodwenvz = ( real32_T )
localB -> ernp5tvitp [ 0 ] ; localB -> grhszs3sjk_kkiq3xxxve [ 0 ] = localP
-> P_145 ; localB -> grhszs3sjk_kkiq3xxxve [ 1 ] = localP -> P_145 ;
muSingleScalarSinCos ( localDW -> lfi3mnae2m [ 2 ] , & localB ->
eep04wvcnw_idx_0 , & localB -> osbuvwrg2r_idx_0 ) ; muSingleScalarSinCos (
localDW -> lfi3mnae2m [ 1 ] , & localB -> eep04wvcnw_idx_1 , & localB ->
osbuvwrg2r_idx_1 ) ; muSingleScalarSinCos ( localDW -> lfi3mnae2m [ 0 ] , &
localB -> eep04wvcnw_idx_2 , & localB -> osbuvwrg2r_idx_2 ) ; localB ->
grhszs3sjk_kkiq3xxxve [ 2 ] = localB -> osbuvwrg2r_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 3 ] = localB -> eep04wvcnw_idx_0 ; localB ->
grhszs3sjk_kkiq3xxxve [ 4 ] = localB -> osbuvwrg2r_idx_0 * localB ->
osbuvwrg2r_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 5 ] = localB ->
eep04wvcnw_idx_0 * localB -> eep04wvcnw_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 6 ] = localB -> osbuvwrg2r_idx_0 ; localB ->
grhszs3sjk_kkiq3xxxve [ 7 ] = localP -> P_100 * localB -> eep04wvcnw_idx_0 *
localB -> osbuvwrg2r_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 8 ] = localB
-> osbuvwrg2r_idx_0 * localB -> eep04wvcnw_idx_1 ; for ( localB -> i = 0 ;
localB -> i < 6 ; localB -> i ++ ) { localB -> djn3bbsoat [ localB -> i ] =
fp0u5nlpgw -> SensorCalibration [ localB -> i ] + localP -> P_101 [ localB ->
i ] ; } localB -> eep04wvcnw_idx_2 = localB -> djn3bbsoat [ 0 ] ; localB ->
eep04wvcnw_idx_1 = localB -> djn3bbsoat [ 1 ] ; localB -> osbuvwrg2r_idx_2 =
localB -> djn3bbsoat [ 2 ] ; localB -> eep04wvcnw_idx_0 = localB ->
djn3bbsoat [ 3 ] ; fggzgj03gr_idx_1 = localB -> djn3bbsoat [ 4 ] ; localB ->
numAccum = localB -> djn3bbsoat [ 5 ] ; localB -> djn3bbsoat [ 0 ] =
fp0u5nlpgw -> HALSensors . HAL_acc_SI . x - localB -> eep04wvcnw_idx_2 ;
localB -> djn3bbsoat [ 1 ] = fp0u5nlpgw -> HALSensors . HAL_acc_SI . y -
localB -> eep04wvcnw_idx_1 ; localB -> djn3bbsoat [ 2 ] = fp0u5nlpgw ->
HALSensors . HAL_acc_SI . z - localB -> osbuvwrg2r_idx_2 ; localB ->
djn3bbsoat [ 3 ] = fp0u5nlpgw -> HALSensors . HAL_gyro_SI . x - localB ->
eep04wvcnw_idx_0 ; localB -> djn3bbsoat [ 4 ] = fp0u5nlpgw -> HALSensors .
HAL_gyro_SI . y - fggzgj03gr_idx_1 ; localB -> djn3bbsoat [ 5 ] = fp0u5nlpgw
-> HALSensors . HAL_gyro_SI . z - localB -> numAccum ; for ( localB -> uIdx =
0 ; localB -> uIdx < 6 ; localB -> uIdx ++ ) { localB -> djn3bbsoat [ localB
-> uIdx ] *= localP -> P_102 [ localB -> uIdx ] ; } localDW -> lpva1qajzk =
0.0F ; localB -> eep04wvcnw_idx_2 = localB -> djn3bbsoat [ 5 ] ; localB ->
denIdx = 1 ; for ( localB -> nz = 0 ; localB -> nz < 5 ; localB -> nz ++ ) {
localB -> eep04wvcnw_idx_2 -= localP -> P_104 [ localB -> denIdx ] * localDW
-> liybiw1jbg [ localB -> nz ] ; localB -> denIdx ++ ; } localDW ->
lpva1qajzk = localB -> eep04wvcnw_idx_2 / localP -> P_104 [ 0 ] ; localB ->
numAccum = localP -> P_103 [ 0 ] * localDW -> lpva1qajzk ; localB -> denIdx =
1 ; for ( localB -> nz = 0 ; localB -> nz < 5 ; localB -> nz ++ ) { localB ->
numAccum += localP -> P_103 [ localB -> denIdx ] * localDW -> liybiw1jbg [
localB -> nz ] ; localB -> denIdx ++ ; } localB -> eep04wvcnw_idx_0 = localB
-> djn3bbsoat [ 3 ] ; localB -> eep04wvcnw_idx_1 = localB -> djn3bbsoat [ 4 ]
; for ( localB -> uIdx = 0 ; localB -> uIdx < 9 ; localB -> uIdx ++ ) {
localB -> grhszs3sjk_cxarnvbvui [ localB -> uIdx ] = localB ->
grhszs3sjk_kkiq3xxxve [ localB -> uIdx ] / localB -> osbuvwrg2r_idx_1 ; }
localB -> uIdx = 0 ; for ( localB -> i = 0 ; localB -> i < 3 ; localB -> i ++
) { localB -> n2sgzma2gj_g2mlkqadfk [ localB -> i ] = 0.0F ; localB ->
n2sgzma2gj_g2mlkqadfk [ localB -> i ] += localB -> grhszs3sjk_cxarnvbvui [
localB -> i ] * localB -> eep04wvcnw_idx_0 ; localB -> n2sgzma2gj_g2mlkqadfk
[ localB -> i ] += localB -> grhszs3sjk_cxarnvbvui [ localB -> i + 3 ] *
localB -> eep04wvcnw_idx_1 ; localB -> n2sgzma2gj_g2mlkqadfk [ localB -> i ]
+= localB -> grhszs3sjk_cxarnvbvui [ localB -> i + 6 ] * localB -> numAccum ;
localB -> denIdx = localB -> i * 5 ; localB -> osbuvwrg2r_idx_1 = localB ->
djn3bbsoat [ localB -> uIdx ] * localP -> P_108 [ 0 ] ; localB -> uIdx ++ ;
localB -> cff = 1 ; localB -> nz = localDW -> cfcgwprtdx ; while ( localB ->
nz < 5 ) { localB -> osbuvwrg2r_idx_1 += localDW -> nbbc5odoq4 [ localB ->
denIdx + localB -> nz ] * localP -> P_108 [ localB -> cff ] ; localB -> cff
++ ; localB -> nz ++ ; } localB -> nz = 0 ; while ( localB -> nz < localDW ->
cfcgwprtdx ) { localB -> osbuvwrg2r_idx_1 += localDW -> nbbc5odoq4 [ localB
-> denIdx + localB -> nz ] * localP -> P_108 [ localB -> cff ] ; localB ->
cff ++ ; localB -> nz ++ ; } localB -> e5fgrdobej_g1smspu5ke [ localB -> i ]
= localB -> osbuvwrg2r_idx_1 ; } localB -> eep04wvcnw_idx_2 =
muSingleScalarFloor ( localP -> P_144 ) ; if ( ( localB ->
e5fgrdobej_g1smspu5ke [ 0 ] < 0.0F ) && ( localP -> P_144 > localB ->
eep04wvcnw_idx_2 ) ) { localB -> osbuvwrg2r_idx_1 = - muSingleScalarPower ( -
localB -> e5fgrdobej_g1smspu5ke [ 0 ] , localP -> P_144 ) ; } else { localB
-> osbuvwrg2r_idx_1 = muSingleScalarPower ( localB -> e5fgrdobej_g1smspu5ke [
0 ] , localP -> P_144 ) ; } if ( ( localB -> e5fgrdobej_g1smspu5ke [ 1 ] <
0.0F ) && ( localP -> P_144 > localB -> eep04wvcnw_idx_2 ) ) {
fggzgj03gr_idx_1 = - muSingleScalarPower ( - localB -> e5fgrdobej_g1smspu5ke
[ 1 ] , localP -> P_144 ) ; } else { fggzgj03gr_idx_1 = muSingleScalarPower (
localB -> e5fgrdobej_g1smspu5ke [ 1 ] , localP -> P_144 ) ; } if ( ( localB
-> e5fgrdobej_g1smspu5ke [ 2 ] < 0.0F ) && ( localP -> P_144 > localB ->
eep04wvcnw_idx_2 ) ) { localB -> eep04wvcnw_idx_2 = - muSingleScalarPower ( -
localB -> e5fgrdobej_g1smspu5ke [ 2 ] , localP -> P_144 ) ; } else { localB
-> eep04wvcnw_idx_2 = muSingleScalarPower ( localB -> e5fgrdobej_g1smspu5ke [
2 ] , localP -> P_144 ) ; } localB -> osbuvwrg2r_idx_1 = muSingleScalarSqrt (
( localB -> osbuvwrg2r_idx_1 + fggzgj03gr_idx_1 ) + localB ->
eep04wvcnw_idx_2 ) ; if ( ( localB -> osbuvwrg2r_idx_1 > localP -> P_13 ) &&
( localB -> osbuvwrg2r_idx_1 < localP -> P_14 ) ) { localB -> p5pzfnaiuu [ 1
] = ( localP -> P_106 * localB -> n2sgzma2gj_g2mlkqadfk [ 2 ] + localDW ->
lfi3mnae2m [ 2 ] ) * localP -> P_83 + muSingleScalarAtan ( localB ->
e5fgrdobej_g1smspu5ke [ 1 ] / localB -> e5fgrdobej_g1smspu5ke [ 2 ] ) *
localP -> P_84 ; localB -> osbuvwrg2r_idx_0 = localP -> P_85 * localB ->
e5fgrdobej_g1smspu5ke [ 0 ] ; if ( localB -> osbuvwrg2r_idx_0 > 1.0F ) {
localB -> osbuvwrg2r_idx_0 = 1.0F ; } else { if ( localB -> osbuvwrg2r_idx_0
< - 1.0F ) { localB -> osbuvwrg2r_idx_0 = - 1.0F ; } } localB -> p5pzfnaiuu [
0 ] = ( localP -> P_106 * localB -> n2sgzma2gj_g2mlkqadfk [ 1 ] + localDW ->
lfi3mnae2m [ 1 ] ) * localP -> P_87 + localP -> P_86 * muSingleScalarAsin (
localB -> osbuvwrg2r_idx_0 ) ; srUpdateBC ( localDW -> h0cudiu0ft ) ; } else
{ localB -> p5pzfnaiuu [ 0 ] = localP -> P_106 * localB ->
n2sgzma2gj_g2mlkqadfk [ 1 ] + localDW -> lfi3mnae2m [ 1 ] ; localB ->
p5pzfnaiuu [ 1 ] = localP -> P_106 * localB -> n2sgzma2gj_g2mlkqadfk [ 2 ] +
localDW -> lfi3mnae2m [ 2 ] ; srUpdateBC ( localDW -> oa1muqt4on ) ; } localB
-> octkfvursp [ 0 ] = localP -> P_106 * localB -> n2sgzma2gj_g2mlkqadfk [ 0 ]
+ localDW -> lfi3mnae2m [ 0 ] ; localB -> octkfvursp [ 1 ] = localB ->
p5pzfnaiuu [ 0 ] ; localB -> octkfvursp [ 2 ] = localB -> p5pzfnaiuu [ 1 ] ;
de3g0eec4m = localDW -> npsllq52wf ; if ( de3g0eec4m < localP -> P_33 ) {
localB -> enwpjq4sny [ 0 ] = fp0u5nlpgw -> VisionSensors . opticalFlow_data [
0 ] ; localB -> enwpjq4sny [ 1 ] = fp0u5nlpgw -> VisionSensors .
opticalFlow_data [ 1 ] ; localB -> enwpjq4sny [ 2 ] = fp0u5nlpgw ->
VisionSensors . opticalFlow_data [ 2 ] ; } else { localB -> osbuvwrg2r_idx_1
= localP -> P_88 * ( real32_T ) localB -> ernp5tvitp [ 0 ] ; localB ->
enwpjq4sny [ 0 ] = fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 0 ] *
localB -> osbuvwrg2r_idx_1 * localP -> P_89 ; localB -> enwpjq4sny [ 1 ] =
fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 1 ] * localB ->
osbuvwrg2r_idx_1 * localP -> P_89 ; localB -> enwpjq4sny [ 2 ] = fp0u5nlpgw
-> VisionSensors . opticalFlow_data [ 2 ] * localB -> osbuvwrg2r_idx_1 *
localP -> P_89 ; } localB -> osbuvwrg2r_idx_1 = localB -> enwpjq4sny [ 0 ] ;
fggzgj03gr_idx_1 = localB -> enwpjq4sny [ 1 ] ; if ( localDW -> pvn1aiza5a !=
0 ) { localDW -> kzeijhdtif [ 0 ] = localB -> b5osnmhsrd [ 0 ] ; localDW ->
kzeijhdtif [ 1 ] = localB -> b5osnmhsrd [ 1 ] ; } for ( localB -> i = 0 ;
localB -> i < 2 ; localB -> i ++ ) { localB -> nw12b21b42_llw0u2ae0v [ localB
-> i ] = localDW -> kzeijhdtif [ localB -> i ] ; localB -> uIdx = localB -> i
* 5 ; localB -> eep04wvcnw_idx_2 = localB -> djn3bbsoat [ localB -> i + 3 ] ;
localB -> denIdx = 1 ; for ( localB -> nz = 0 ; localB -> nz < 5 ; localB ->
nz ++ ) { localB -> eep04wvcnw_idx_2 -= localDW -> heeedoxzle [ localB ->
uIdx + localB -> nz ] * localP -> P_111 [ localB -> denIdx ] ; localB ->
denIdx ++ ; } localDW -> dhhdwwczx2 [ localB -> i ] = localB ->
eep04wvcnw_idx_2 / localP -> P_111 [ 0 ] ; localB -> eep04wvcnw_idx_2 =
localP -> P_110 [ 0 ] * localDW -> dhhdwwczx2 [ localB -> i ] ; localB ->
denIdx = 1 ; for ( localB -> nz = 0 ; localB -> nz < 5 ; localB -> nz ++ ) {
localB -> eep04wvcnw_idx_2 += localDW -> heeedoxzle [ localB -> uIdx + localB
-> nz ] * localP -> P_110 [ localB -> denIdx ] ; localB -> denIdx ++ ; }
localB -> kitmhlyutx [ localB -> i ] = localB -> eep04wvcnw_idx_2 * localP ->
P_113 ; } localB -> kctmfodxtl_dhmrxtyqop [ 0 ] = localDW -> gqxdiwstsm [ 0 ]
; localB -> kctmfodxtl_dhmrxtyqop [ 1 ] = localDW -> gqxdiwstsm [ 1 ] ;
localB -> oir0suwf2k_jwzvbuczlb [ 0 ] = localB -> kitmhlyutx [ 0 ] - localB
-> kctmfodxtl_dhmrxtyqop [ 0 ] ; localB -> oir0suwf2k_jwzvbuczlb [ 1 ] =
localB -> kitmhlyutx [ 1 ] - localB -> kctmfodxtl_dhmrxtyqop [ 1 ] ; localB
-> eep04wvcnw_idx_2 = muSingleScalarAbs ( localB -> djn3bbsoat [ 3 ] ) ;
localB -> osbuvwrg2r_idx_0 = muSingleScalarAbs ( localB -> djn3bbsoat [ 4 ] )
; localB -> ewcvsl00tt = ( ( ( ( muSingleScalarAbs ( localB -> octkfvursp [ 1
] ) <= localP -> P_20 ) && ( muSingleScalarAbs ( localB -> octkfvursp [ 2 ] )
<= localP -> P_22 ) && ( localB -> eep04wvcnw_idx_2 <= localP -> P_24 ) && (
localB -> osbuvwrg2r_idx_0 <= localP -> P_25 ) && ( muSingleScalarAbs (
localB -> oir0suwf2k_jwzvbuczlb [ 0 ] ) <= localP -> P_18 ) && (
muSingleScalarAbs ( localB -> oir0suwf2k_jwzvbuczlb [ 1 ] ) <= localP -> P_19
) ) || ( ( localB -> eep04wvcnw_idx_2 <= localP -> P_21 ) && ( localB ->
osbuvwrg2r_idx_0 <= localP -> P_23 ) ) ) && ( muSingleScalarAbs ( localB ->
enwpjq4sny [ 0 ] - localDW -> a3uar2xrsb [ 0 ] ) <= localP -> P_26 ) && (
muSingleScalarAbs ( localB -> enwpjq4sny [ 1 ] - localDW -> a3uar2xrsb [ 1 ]
) <= localP -> P_27 ) && ( ( real32_T ) localB -> ernp5tvitp [ 0 ] <= localP
-> P_28 ) ) ; dk05t4kqcv = localB -> ewcvsl00tt ; ogybdje05f = localB ->
ewcvsl00tt ; if ( ogybdje05f ) { if ( ! localDW -> j20mj4ai3a ) { if (
rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> j20mj4ai3a = true ; } localB -> eep04wvcnw_idx_2 = localB ->
osbuvwrg2r_idx_1 - ( localP -> P_148 [ 0 ] * localB -> nw12b21b42_llw0u2ae0v
[ 0 ] + localP -> P_148 [ 2 ] * localB -> nw12b21b42_llw0u2ae0v [ 1 ] ) ;
localB -> osbuvwrg2r_idx_0 = fggzgj03gr_idx_1 - ( localP -> P_148 [ 1 ] *
localB -> nw12b21b42_llw0u2ae0v [ 0 ] + localP -> P_148 [ 3 ] * localB ->
nw12b21b42_llw0u2ae0v [ 1 ] ) ; localB -> bkehspj2gn [ 0 ] = 0.0F ; localB ->
bkehspj2gn [ 0 ] += localB -> kyi2cghtbd [ 0 ] * localB -> eep04wvcnw_idx_2 ;
localB -> bkehspj2gn [ 0 ] += localB -> kyi2cghtbd [ 2 ] * localB ->
osbuvwrg2r_idx_0 ; localB -> bkehspj2gn [ 1 ] = 0.0F ; localB -> bkehspj2gn [
1 ] += localB -> kyi2cghtbd [ 1 ] * localB -> eep04wvcnw_idx_2 ; localB ->
bkehspj2gn [ 1 ] += localB -> kyi2cghtbd [ 3 ] * localB -> osbuvwrg2r_idx_0 ;
srUpdateBC ( localDW -> nuogwfijir ) ; } else { if ( localDW -> j20mj4ai3a )
{ ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> bkehspj2gn [ 0 ] = localP -> P_91 ; localB -> bkehspj2gn [ 1 ] =
localP -> P_91 ; localDW -> j20mj4ai3a = false ; } } localB -> i53pibnrls [ 0
] = localB -> bkehspj2gn [ 0 ] + localB -> nw12b21b42_llw0u2ae0v [ 0 ] ;
localB -> i53pibnrls [ 1 ] = localB -> bkehspj2gn [ 1 ] + localB ->
nw12b21b42_llw0u2ae0v [ 1 ] ; muSingleScalarSinCos ( localB -> octkfvursp [ 0
] , & localB -> eep04wvcnw_idx_2 , & localB -> osbuvwrg2r_idx_0 ) ;
muSingleScalarSinCos ( localB -> octkfvursp [ 1 ] , & localB ->
b5osnmhsrd_idx_1 , & localB -> oxxshm0p0o_idx_1 ) ; muSingleScalarSinCos (
localB -> octkfvursp [ 2 ] , & localB -> b5osnmhsrd_idx_2 , & localB ->
oxxshm0p0o_idx_2 ) ; localB -> grhszs3sjk_kkiq3xxxve [ 0 ] = localB ->
oxxshm0p0o_idx_1 * localB -> osbuvwrg2r_idx_0 ; localB -> osbuvwrg2r_idx_2 =
localB -> b5osnmhsrd_idx_2 * localB -> b5osnmhsrd_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 1 ] = localB -> osbuvwrg2r_idx_2 * localB ->
osbuvwrg2r_idx_0 - localB -> oxxshm0p0o_idx_2 * localB -> eep04wvcnw_idx_2 ;
localB -> cgkzo2biyi_dypejvacrn = localB -> oxxshm0p0o_idx_2 * localB ->
b5osnmhsrd_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 2 ] = localB ->
cgkzo2biyi_dypejvacrn * localB -> osbuvwrg2r_idx_0 + localB ->
b5osnmhsrd_idx_2 * localB -> eep04wvcnw_idx_2 ; localB ->
grhszs3sjk_kkiq3xxxve [ 3 ] = localB -> oxxshm0p0o_idx_1 * localB ->
eep04wvcnw_idx_2 ; localB -> grhszs3sjk_kkiq3xxxve [ 4 ] = localB ->
osbuvwrg2r_idx_2 * localB -> eep04wvcnw_idx_2 + localB -> oxxshm0p0o_idx_2 *
localB -> osbuvwrg2r_idx_0 ; localB -> grhszs3sjk_kkiq3xxxve [ 5 ] = localB
-> cgkzo2biyi_dypejvacrn * localB -> eep04wvcnw_idx_2 - localB ->
b5osnmhsrd_idx_2 * localB -> osbuvwrg2r_idx_0 ; localB ->
grhszs3sjk_kkiq3xxxve [ 6 ] = - localB -> b5osnmhsrd_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 7 ] = localB -> b5osnmhsrd_idx_2 * localB ->
oxxshm0p0o_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 8 ] = localB ->
oxxshm0p0o_idx_2 * localB -> oxxshm0p0o_idx_1 ; for ( localB -> uIdx = 0 ;
localB -> uIdx < 3 ; localB -> uIdx ++ ) { localB -> c01pvjzgld_nz4o0shxby =
( real_T ) localB -> grhszs3sjk_kkiq3xxxve [ localB -> uIdx ] * localDW ->
lw3rw5s0ye [ 0 ] ; localB -> mTheta = ( real_T ) localB ->
grhszs3sjk_kkiq3xxxve [ localB -> uIdx + 3 ] * localDW -> lw3rw5s0ye [ 1 ] ;
localB -> total = localB -> grhszs3sjk_kkiq3xxxve [ localB -> uIdx + 6 ] *
localB -> ernp5tvitp [ 1 ] ; localB -> bkuhtmeamg_pbm3vprmfu [ localB -> uIdx
] = localB -> total + ( localB -> mTheta + localB -> c01pvjzgld_nz4o0shxby )
; localB -> grhszs3sjk_cv5hdgrwft [ localB -> uIdx ] = localB -> total + (
localB -> mTheta + localB -> c01pvjzgld_nz4o0shxby ) ; } localB ->
aujstwbrse_cl54gopm0x [ 0 ] = localB -> b5vwzreuo4_idx_0 ; localB ->
aujstwbrse_cl54gopm0x [ 1 ] = localB -> b5vwzreuo4_idx_1 ; localB ->
aujstwbrse_cl54gopm0x [ 2 ] = localB -> ceqpqrxfmi_ldqodwenvz ; localB ->
aujstwbrse_cl54gopm0x [ 3 ] = localB -> octkfvursp [ 0 ] ; localB ->
aujstwbrse_cl54gopm0x [ 4 ] = localB -> octkfvursp [ 1 ] ; localB ->
aujstwbrse_cl54gopm0x [ 5 ] = localB -> octkfvursp [ 2 ] ; localB ->
aujstwbrse_cl54gopm0x [ 6 ] = localB -> i53pibnrls [ 0 ] ; localB ->
aujstwbrse_cl54gopm0x [ 7 ] = localB -> i53pibnrls [ 1 ] ; localB ->
aujstwbrse_cl54gopm0x [ 8 ] = ( real32_T ) localB -> bkuhtmeamg_pbm3vprmfu [
2 ] ; localB -> aujstwbrse_cl54gopm0x [ 9 ] = localB -> eep04wvcnw_idx_0 ;
localB -> aujstwbrse_cl54gopm0x [ 10 ] = localB -> eep04wvcnw_idx_1 ; localB
-> aujstwbrse_cl54gopm0x [ 11 ] = localB -> numAccum ; localB -> mTheta =
mod_L9P39Tyf ( localDW -> hmetbef2mf ) ; localB -> c01pvjzgld_nz4o0shxby =
mod_L9P39Tyf ( localB -> mTheta - localP -> P_53 / 2.0 ) ; localB -> mTheta =
mod_L9P39Tyf ( localP -> P_53 / 2.0 + localB -> mTheta ) ; localB -> total =
0.0 ; localB -> count = 0.0 ; for ( localB -> i = 0 ; localB -> i < 120 ;
localB -> i ++ ) { vector_idx_1 = ( int8_T ) ( 59 - localB -> i ) ; for (
localB -> nz = 0 ; localB -> nz < 160 ; localB -> nz ++ ) { vector_idx_0 = (
int8_T ) ( localB -> nz - 79 ) ; localB -> angle = mod_L9P39Tyf (
57.295779513082323 * muDoubleScalarAtan2 ( vector_idx_1 , vector_idx_0 ) -
90.0 ) ; if ( ( muDoubleScalarSqrt ( vector_idx_0 * vector_idx_0 +
vector_idx_1 * vector_idx_1 ) < 25.0 ) && ( ( ( localB -> mTheta < localB ->
c01pvjzgld_nz4o0shxby ) && ( ( localB -> angle > localB ->
c01pvjzgld_nz4o0shxby ) || ( localB -> angle < localB -> mTheta ) ) ) || ( (
localB -> angle > localB -> c01pvjzgld_nz4o0shxby ) && ( localB -> angle <
localB -> mTheta ) ) ) ) { localB -> total ++ ; localB -> count += ( real_T )
ay1xsyaztb [ 120 * localB -> nz + localB -> i ] ; } } } if ( localB -> count
/ localB -> total < 0.7 ) { localB -> mTheta = localP -> P_54 ; srUpdateBC (
localDW -> b3ewiobpsi ) ; } else { localB -> mTheta = localB -> hvdur1yjwa ;
srUpdateBC ( localDW -> iu11iwpdyn ) ; } for ( localB -> i = 0 ; localB -> i
< 19200 ; localB -> i ++ ) { localB -> edu4rs0xq3_mbvzarwird [ localB -> i ]
= ay1xsyaztb [ localB -> i ] ; } localB -> total = mod_L9P39Tyf ( localDW ->
hmetbef2mf + 180.0 ) ; localB -> c01pvjzgld_nz4o0shxby = mod_L9P39Tyf (
localB -> total - localB -> mTheta / 2.0 ) ; localB -> mTheta = mod_L9P39Tyf
( localB -> mTheta / 2.0 + localB -> total ) ; for ( localB -> i = 0 ; localB
-> i < 120 ; localB -> i ++ ) { for ( localB -> nz = 0 ; localB -> nz < 160 ;
localB -> nz ++ ) { localB -> uIdx = 120 * localB -> nz + localB -> i ; if (
ay1xsyaztb [ localB -> uIdx ] ) { localB -> angle = mod_L9P39Tyf (
muDoubleScalarAtan2 ( ( int8_T ) ( 59 - localB -> i ) , ( int8_T ) ( localB
-> nz - 79 ) ) * 57.295779513082323 - 90.0 ) ; if ( ( localB -> mTheta <
localB -> c01pvjzgld_nz4o0shxby ) && ( ( localB -> angle > localB ->
c01pvjzgld_nz4o0shxby ) || ( localB -> angle < localB -> mTheta ) ) ) {
localB -> edu4rs0xq3_mbvzarwird [ localB -> uIdx ] = false ; } else { if ( (
localB -> angle > localB -> c01pvjzgld_nz4o0shxby ) && ( localB -> angle <
localB -> mTheta ) ) { localB -> edu4rs0xq3_mbvzarwird [ localB -> uIdx ] =
false ; } } } } } localB -> nz = localB -> edu4rs0xq3_mbvzarwird [ 0 ] ; for
( localB -> i = 0 ; localB -> i < 19199 ; localB -> i ++ ) { localB -> nz +=
localB -> edu4rs0xq3_mbvzarwird [ localB -> i + 1 ] ; } if ( localB -> nz ==
0 ) { localB -> pcafmpcl4b = 0.0 ; } else { for ( localB -> uIdx = 0 ; localB
-> uIdx < 120 ; localB -> uIdx ++ ) { localB -> dv1 [ localB -> uIdx ] = (
real_T ) localB -> uIdx + 1.0 ; } for ( localB -> uIdx = 0 ; localB -> uIdx <
160 ; localB -> uIdx ++ ) { localB -> dv [ localB -> uIdx ] = ( real_T )
localB -> uIdx + 1.0 ; } ndgrid_RnXP2lml ( localB -> dv1 , localB -> dv ,
localB -> y , localB -> x ) ; localB -> nz = 0 ; localB -> uIdx = 0 ; for (
localB -> i = 0 ; localB -> i < 19200 ; localB -> i ++ ) { if ( localB ->
edu4rs0xq3_mbvzarwird [ localB -> i ] ) { localB -> nz ++ ; localB -> b_data
[ localB -> uIdx ] = ( int16_T ) ( localB -> i + 1 ) ; localB -> uIdx ++ ; }
} localB -> x_size [ 0 ] = localB -> nz ; localB -> x_size [ 1 ] = 2 ; for (
localB -> uIdx = 0 ; localB -> uIdx < localB -> nz ; localB -> uIdx ++ ) {
localB -> i = localB -> b_data [ localB -> uIdx ] - 1 ; localB -> x_data [
localB -> uIdx ] = localB -> x [ localB -> i ] ; localB -> x_data [ localB ->
uIdx + localB -> nz ] = localB -> y [ localB -> i ] ; } l5fvh44l1b ( localB
-> x_data , localB -> x_size , localB -> centroid ) ; localB -> pcafmpcl4b =
muDoubleScalarAtan2 ( 60.0 - localB -> centroid [ 1 ] , localB -> centroid [
0 ] - 80.0 ) * 57.295779513082323 ; localB -> pcafmpcl4b -= 90.0 ; localB ->
pcafmpcl4b = mod_L9P39Tyf ( localB -> pcafmpcl4b ) ; } localB ->
c01pvjzgld_nz4o0shxby = localP -> P_42 * localB -> pcafmpcl4b ; localB ->
ftda3noqkg = localP -> P_51 * muDoubleScalarCos ( localB ->
c01pvjzgld_nz4o0shxby ) + localDW -> me4j0lrjd2 ; localB -> nkkovac5ti =
localP -> P_44 * muDoubleScalarSin ( localB -> c01pvjzgld_nz4o0shxby ) *
localP -> P_51 + localDW -> mb3yoxlyu3 ; if ( localP -> P_167 ) {
muSingleScalarSinCos ( localB -> octkfvursp [ 0 ] , & localB ->
osbuvwrg2r_idx_2 , & localB -> cgkzo2biyi_dypejvacrn ) ; localB ->
eep04wvcnw_idx_2 = ( real32_T ) localB -> ftda3noqkg - localB ->
b5vwzreuo4_idx_0 ; localB -> b5osnmhsrd_idx_1 = ( real32_T ) localB ->
nkkovac5ti - localB -> b5vwzreuo4_idx_1 ; localB -> oxxshm0p0o_idx_1 = localB
-> cgkzo2biyi_dypejvacrn * localB -> eep04wvcnw_idx_2 + localB ->
osbuvwrg2r_idx_2 * localB -> b5osnmhsrd_idx_1 ; if ( localB ->
oxxshm0p0o_idx_1 > localP -> P_77 ) { localB -> oxxshm0p0o_idx_1 = localP ->
P_77 ; } else { if ( localB -> oxxshm0p0o_idx_1 < localP -> P_78 ) { localB
-> oxxshm0p0o_idx_1 = localP -> P_78 ; } } localB -> ciysnkgium_ppxrqq0gsf [
0 ] = localP -> P_79 [ 0 ] * localB -> oxxshm0p0o_idx_1 + localP -> P_75 [ 0
] * localB -> i53pibnrls [ 0 ] ; localB -> oxxshm0p0o_idx_1 = localP -> P_76
* localB -> osbuvwrg2r_idx_2 * localB -> eep04wvcnw_idx_2 + localB ->
cgkzo2biyi_dypejvacrn * localB -> b5osnmhsrd_idx_1 ; if ( localB ->
oxxshm0p0o_idx_1 > localP -> P_77 ) { localB -> oxxshm0p0o_idx_1 = localP ->
P_77 ; } else { if ( localB -> oxxshm0p0o_idx_1 < localP -> P_78 ) { localB
-> oxxshm0p0o_idx_1 = localP -> P_78 ; } } localB -> ciysnkgium_ppxrqq0gsf [
1 ] = localP -> P_79 [ 1 ] * localB -> oxxshm0p0o_idx_1 + localP -> P_75 [ 1
] * localB -> i53pibnrls [ 1 ] ; } else { localB -> ciysnkgium_ppxrqq0gsf [ 0
] = ipxpc4eli1 -> orient_ref [ 1 ] ; localB -> ciysnkgium_ppxrqq0gsf [ 1 ] =
ipxpc4eli1 -> orient_ref [ 2 ] ; } localB -> oxxshm0p0o_idx_1 = localB ->
ciysnkgium_ppxrqq0gsf [ 0 ] - localB -> octkfvursp [ 1 ] ; localB ->
jl4zglnkcz [ 0 ] = localB -> oxxshm0p0o_idx_1 - localP -> P_117 * localDW ->
cosb2ibhn3 [ 0 ] ; localB -> k1lgyzog01 [ 0 ] = localDW -> fuo05buemm [ 0 ] ;
localB -> ciysnkgium_ppxrqq0gsf [ 0 ] = localB -> oxxshm0p0o_idx_1 ; localB
-> oxxshm0p0o_idx_1 = localB -> ciysnkgium_ppxrqq0gsf [ 1 ] - localB ->
octkfvursp [ 2 ] ; localB -> jl4zglnkcz [ 1 ] = localB -> oxxshm0p0o_idx_1 -
localP -> P_117 * localDW -> cosb2ibhn3 [ 1 ] ; localB -> k1lgyzog01 [ 1 ] =
localDW -> fuo05buemm [ 1 ] ; localB -> eep04wvcnw_idx_0 = ( localP -> P_124
[ 1 ] * localB -> oxxshm0p0o_idx_1 + localP -> P_123 * localB -> k1lgyzog01 [
1 ] ) - localP -> P_118 [ 1 ] * localB -> eep04wvcnw_idx_0 ; if ( localP ->
P_166 ) { localB -> eep04wvcnw_idx_1 = ( localP -> P_124 [ 0 ] * localB ->
ciysnkgium_ppxrqq0gsf [ 0 ] + localP -> P_123 * localB -> k1lgyzog01 [ 0 ] )
- localP -> P_118 [ 0 ] * localB -> eep04wvcnw_idx_1 ; } else { localB ->
eep04wvcnw_idx_1 = ( ( localP -> P_124 [ 0 ] * localB ->
ciysnkgium_ppxrqq0gsf [ 0 ] + localP -> P_123 * localB -> k1lgyzog01 [ 0 ] )
- localP -> P_118 [ 0 ] * localB -> eep04wvcnw_idx_1 ) + localP -> P_141 ; }
ctv5xw2mss = localDW -> i13qoukcsn ; localB -> f25x251bac = ( ctv5xw2mss <
localP -> P_32 ) ; if ( ( ! localB -> f25x251bac ) && ( localDW -> gafzug4yea
== 1 ) ) { localDW -> ppp4ajc3p1 = localP -> P_127 ; } if ( localDW ->
ppp4ajc3p1 >= localP -> P_128 ) { localDW -> ppp4ajc3p1 = localP -> P_128 ; }
else { if ( localDW -> ppp4ajc3p1 <= localP -> P_129 ) { localDW ->
ppp4ajc3p1 = localP -> P_129 ; } } localB -> oxxshm0p0o_idx_1 = ( real32_T )
localP -> P_55 - localB -> ceqpqrxfmi_ldqodwenvz ; bhjzwuyxdg = ctv5xw2mss +
localP -> P_160 ; if ( bhjzwuyxdg > localP -> P_29 ) { localB -> nir2sesw4o =
localP -> P_161 ; } else { localB -> nir2sesw4o = bhjzwuyxdg ; } localB ->
cdicpgn145 = localP -> P_134 * localB -> oxxshm0p0o_idx_1 ; if ( localB ->
f25x251bac ) { localB -> eep04wvcnw_idx_2 = localP -> P_82 * localP -> P_125
; } else { localB -> eep04wvcnw_idx_2 = ( localP -> P_81 * localB ->
oxxshm0p0o_idx_1 + localDW -> ppp4ajc3p1 ) - localP -> P_80 * ( real32_T )
localB -> bkuhtmeamg_pbm3vprmfu [ 2 ] ; } localB -> osbuvwrg2r_idx_0 = localP
-> P_125 + localB -> eep04wvcnw_idx_2 ; if ( localB -> osbuvwrg2r_idx_0 >
localP -> P_130 ) { localB -> osbuvwrg2r_idx_0 = localP -> P_130 ; } else {
if ( localB -> osbuvwrg2r_idx_0 < localP -> P_131 ) { localB ->
osbuvwrg2r_idx_0 = localP -> P_131 ; } } localB -> oxxshm0p0o_idx_1 = (
ipxpc4eli1 -> orient_ref [ 0 ] - localB -> octkfvursp [ 0 ] ) * localP ->
P_132 - localP -> P_133 * localB -> numAccum ; for ( localB -> uIdx = 0 ;
localB -> uIdx < 4 ; localB -> uIdx ++ ) { localB -> eep04wvcnw_idx_2 =
localB -> a1bbiq2a3a [ localB -> uIdx + 12 ] * localB -> eep04wvcnw_idx_0 + (
localB -> a1bbiq2a3a [ localB -> uIdx + 8 ] * localB -> eep04wvcnw_idx_1 + (
localB -> a1bbiq2a3a [ localB -> uIdx + 4 ] * localB -> oxxshm0p0o_idx_1 +
localB -> a1bbiq2a3a [ localB -> uIdx ] * localB -> osbuvwrg2r_idx_0 ) ) ;
localB -> fv [ localB -> uIdx ] = localB -> eep04wvcnw_idx_2 ; } localB ->
osbuvwrg2r_idx_0 = localP -> P_135 * localB -> fv [ 0 ] ; if ( localB ->
osbuvwrg2r_idx_0 > localP -> P_136 ) { localB -> osbuvwrg2r_idx_0 = localP ->
P_136 ; } else { if ( localB -> osbuvwrg2r_idx_0 < localP -> P_137 ) { localB
-> osbuvwrg2r_idx_0 = localP -> P_137 ; } } localB -> dz0gwbmcjt [ 0 ] =
localP -> P_138 [ 0 ] * localB -> osbuvwrg2r_idx_0 ; localB ->
osbuvwrg2r_idx_0 = localP -> P_135 * localB -> fv [ 1 ] ; if ( localB ->
osbuvwrg2r_idx_0 > localP -> P_136 ) { localB -> osbuvwrg2r_idx_0 = localP ->
P_136 ; } else { if ( localB -> osbuvwrg2r_idx_0 < localP -> P_137 ) { localB
-> osbuvwrg2r_idx_0 = localP -> P_137 ; } } localB -> dz0gwbmcjt [ 1 ] =
localP -> P_138 [ 1 ] * localB -> osbuvwrg2r_idx_0 ; localB ->
osbuvwrg2r_idx_0 = localP -> P_135 * localB -> fv [ 2 ] ; if ( localB ->
osbuvwrg2r_idx_0 > localP -> P_136 ) { localB -> osbuvwrg2r_idx_0 = localP ->
P_136 ; } else { if ( localB -> osbuvwrg2r_idx_0 < localP -> P_137 ) { localB
-> osbuvwrg2r_idx_0 = localP -> P_137 ; } } localB -> dz0gwbmcjt [ 2 ] =
localP -> P_138 [ 2 ] * localB -> osbuvwrg2r_idx_0 ; localB ->
osbuvwrg2r_idx_0 = localP -> P_135 * localB -> fv [ 3 ] ; if ( localB ->
osbuvwrg2r_idx_0 > localP -> P_136 ) { localB -> osbuvwrg2r_idx_0 = localP ->
P_136 ; } else { if ( localB -> osbuvwrg2r_idx_0 < localP -> P_137 ) { localB
-> osbuvwrg2r_idx_0 = localP -> P_137 ; } } localB -> dz0gwbmcjt [ 3 ] =
localP -> P_138 [ 3 ] * localB -> osbuvwrg2r_idx_0 ; f1qxkoe3mf = localDW ->
dxm3w2i52x ; if ( f1qxkoe3mf > localP -> P_50 ) { localB ->
hrsldhjj3q_dhamdvybc1 = localB -> ceqpqrxfmi_ldqodwenvz - localB ->
hrsldhjj3q_dhamdvybc1 ; localB -> c01pvjzgld_nz4o0shxby = fp0u5nlpgw ->
VisionSensors . opticalFlow_data [ 2 ] ; localB -> mTheta = fp0u5nlpgw ->
VisionSensors . opticalFlow_data [ 2 ] ; } else { localB ->
hrsldhjj3q_dhamdvybc1 = localP -> P_143 ; localB -> c01pvjzgld_nz4o0shxby =
localP -> P_48 ; localB -> mTheta = localP -> P_48 ; } localB -> cyov5ky1ov =
( real_T ) ( localB -> mTheta == localP -> P_1 ) * localDW -> bw2ribqmwm + (
real_T ) ( localB -> c01pvjzgld_nz4o0shxby == localP -> P_1 ) ; katpqstrxz =
f1qxkoe3mf + localP -> P_162 ; if ( katpqstrxz > localP -> P_30 ) { localB ->
gfrwlpjnn2 = localP -> P_163 ; } else { localB -> gfrwlpjnn2 = katpqstrxz ; }
if ( ( muSingleScalarAbs ( localB -> b5vwzreuo4_idx_0 ) > localP -> P_7 ) ||
( muSingleScalarAbs ( localB -> b5vwzreuo4_idx_1 ) > localP -> P_8 ) ) {
ghadbep3bb ( & localB -> i0mkwvniar , & localP -> ghadbep3bbv ) ; } else if (
( ( muSingleScalarAbs ( fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 0 ]
) > localP -> P_11 ) && ( muSingleScalarAbs ( localP -> P_139 * fp0u5nlpgw ->
VisionSensors . opticalFlow_data [ 0 ] - localB -> i53pibnrls [ 0 ] ) >
localP -> P_9 ) ) || ( ( muSingleScalarAbs ( localP -> P_140 * fp0u5nlpgw ->
VisionSensors . opticalFlow_data [ 1 ] - localB -> i53pibnrls [ 1 ] ) >
localP -> P_10 ) && ( muSingleScalarAbs ( fp0u5nlpgw -> VisionSensors .
opticalFlow_data [ 1 ] ) > localP -> P_12 ) ) ) { ghadbep3bb ( & localB ->
i0mkwvniar , & localP -> acfz1zxm4t ) ; } else if ( localB -> cyov5ky1ov >
localP -> P_0 ) { ghadbep3bb ( & localB -> i0mkwvniar , & localP ->
clwiujjdqo ) ; } else if ( muSingleScalarAbs ( localB ->
hrsldhjj3q_dhamdvybc1 ) > localP -> P_49 ) { ghadbep3bb ( & localB ->
i0mkwvniar , & localP -> jvbbqhrajh ) ; } else { ghadbep3bb ( & localB ->
i0mkwvniar , & localP -> ciy1c2o0rv ) ; } localB -> k0vc4prqez_fqdqrf4qbc [ 0
] = localB -> in00o5ix5a_idx_0 ; localB -> k0vc4prqez_fqdqrf4qbc [ 1 ] =
localB -> in00o5ix5a_idx_1 ; localB -> in00o5ix5a_idx_0 = localP -> P_56 [ 0
] * localB -> k0vc4prqez_fqdqrf4qbc [ 0 ] + localP -> P_56 [ 2 ] * localB ->
k0vc4prqez_fqdqrf4qbc [ 1 ] ; localB -> in00o5ix5a_idx_1 = localP -> P_56 [ 1
] * localB -> k0vc4prqez_fqdqrf4qbc [ 0 ] + localP -> P_56 [ 3 ] * localB ->
k0vc4prqez_fqdqrf4qbc [ 1 ] ; for ( localB -> uIdx = 0 ; localB -> uIdx < 3 ;
localB -> uIdx ++ ) { localB -> nmdhai2lmc [ localB -> uIdx ] = ( ( localB ->
grhszs3sjk_kkiq3xxxve [ 3 * localB -> uIdx + 1 ] * localB ->
e5fgrdobej_g1smspu5ke [ 1 ] + localB -> grhszs3sjk_kkiq3xxxve [ 3 * localB ->
uIdx ] * localB -> e5fgrdobej_g1smspu5ke [ 0 ] ) + localB ->
grhszs3sjk_kkiq3xxxve [ 3 * localB -> uIdx + 2 ] * localB ->
e5fgrdobej_g1smspu5ke [ 2 ] ) + localP -> P_70 [ localB -> uIdx ] ; } localB
-> c01pvjzgld_nz4o0shxby = localB -> nmdhai2lmc [ 2 ] ; localB -> centroid [
0 ] = localP -> P_57 [ 0 ] * localB -> nmdhai2lmc [ 2 ] ; localB -> centroid
[ 1 ] = localP -> P_57 [ 1 ] * localB -> nmdhai2lmc [ 2 ] ; ig4cpcv0zy =
hjdzwdsemb ; if ( ig4cpcv0zy ) { if ( ! localDW -> jtnjtissuf ) { if (
rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> jtnjtissuf = true ; } localB -> a1bbiq2a3a_merlcviukg -= ( localP
-> P_58 [ 0 ] * localB -> k0vc4prqez_fqdqrf4qbc [ 0 ] + localP -> P_58 [ 1 ]
* localB -> k0vc4prqez_fqdqrf4qbc [ 1 ] ) + localP -> P_62 * localB ->
c01pvjzgld_nz4o0shxby ; localB -> j42uqprebt [ 0 ] = localB -> h2ctrfi3m4 [ 0
] * localB -> a1bbiq2a3a_merlcviukg ; localB -> j42uqprebt [ 1 ] = localB ->
h2ctrfi3m4 [ 1 ] * localB -> a1bbiq2a3a_merlcviukg ; srUpdateBC ( localDW ->
btfjf5acqg ) ; } else { if ( localDW -> jtnjtissuf ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> j42uqprebt [ 0 ] = localP -> P_34 ; localB -> j42uqprebt [ 1 ] =
localP -> P_34 ; localDW -> jtnjtissuf = false ; } } localB -> j5wzgpzqi4 [ 0
] = ( localB -> centroid [ 0 ] + localB -> in00o5ix5a_idx_0 ) + localB ->
j42uqprebt [ 0 ] ; localB -> j5wzgpzqi4 [ 1 ] = ( localB -> centroid [ 1 ] +
localB -> in00o5ix5a_idx_1 ) + localB -> j42uqprebt [ 1 ] ;
muSingleScalarSinCos ( localB -> octkfvursp [ 0 ] , & localB ->
b5vwzreuo4_idx_0 , & localB -> b5vwzreuo4_idx_1 ) ; muSingleScalarSinCos (
localB -> octkfvursp [ 1 ] , & localB -> pyvm2ihwbp_idx_1 , & localB ->
kgtfcegdc5_idx_1 ) ; muSingleScalarSinCos ( localB -> octkfvursp [ 2 ] , &
localB -> pyvm2ihwbp_idx_2 , & localB -> kgtfcegdc5_idx_2 ) ; localB ->
grhszs3sjk_kkiq3xxxve [ 0 ] = localB -> kgtfcegdc5_idx_1 * localB ->
b5vwzreuo4_idx_1 ; localB -> osbuvwrg2r_idx_2 = localB -> pyvm2ihwbp_idx_2 *
localB -> pyvm2ihwbp_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 1 ] = localB
-> osbuvwrg2r_idx_2 * localB -> b5vwzreuo4_idx_1 - localB -> kgtfcegdc5_idx_2
* localB -> b5vwzreuo4_idx_0 ; localB -> cgkzo2biyi_dypejvacrn = localB ->
kgtfcegdc5_idx_2 * localB -> pyvm2ihwbp_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 2 ] = localB -> cgkzo2biyi_dypejvacrn * localB ->
b5vwzreuo4_idx_1 + localB -> pyvm2ihwbp_idx_2 * localB -> b5vwzreuo4_idx_0 ;
localB -> grhszs3sjk_kkiq3xxxve [ 3 ] = localB -> kgtfcegdc5_idx_1 * localB
-> b5vwzreuo4_idx_0 ; localB -> grhszs3sjk_kkiq3xxxve [ 4 ] = localB ->
osbuvwrg2r_idx_2 * localB -> b5vwzreuo4_idx_0 + localB -> kgtfcegdc5_idx_2 *
localB -> b5vwzreuo4_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 5 ] = localB
-> cgkzo2biyi_dypejvacrn * localB -> b5vwzreuo4_idx_0 - localB ->
pyvm2ihwbp_idx_2 * localB -> b5vwzreuo4_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 6 ] = - localB -> pyvm2ihwbp_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 7 ] = localB -> pyvm2ihwbp_idx_2 * localB ->
kgtfcegdc5_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 8 ] = localB ->
kgtfcegdc5_idx_2 * localB -> kgtfcegdc5_idx_1 ; hjdzwdsemb = ( localB ->
ceqpqrxfmi_ldqodwenvz <= localP -> P_15 ) ; lq42vmb0rf = ( ( localB ->
enwpjq4sny [ 0 ] != localP -> P_16 ) || ( localB -> enwpjq4sny [ 1 ] !=
localP -> P_17 ) ) ; for ( localB -> uIdx = 0 ; localB -> uIdx < 3 ; localB
-> uIdx ++ ) { localB -> bkuhtmeamg_pbm3vprmfu [ localB -> uIdx ] = localB ->
e5fgrdobej_g1smspu5ke [ localB -> uIdx ] - ( ( localB ->
grhszs3sjk_kkiq3xxxve [ localB -> uIdx + 3 ] * localP -> P_71 [ 1 ] + localB
-> grhszs3sjk_kkiq3xxxve [ localB -> uIdx ] * localP -> P_71 [ 0 ] ) + localB
-> grhszs3sjk_kkiq3xxxve [ localB -> uIdx + 6 ] * localP -> P_71 [ 2 ] ) ; }
localB -> bbwy42xxao [ 0 ] = ( real32_T ) ( localP -> P_47 * localB ->
bkuhtmeamg_pbm3vprmfu [ 0 ] ) * ( real32_T ) lq42vmb0rf * ( real32_T )
hjdzwdsemb ; localB -> bbwy42xxao [ 1 ] = ( real32_T ) ( localP -> P_47 *
localB -> bkuhtmeamg_pbm3vprmfu [ 1 ] ) * ( real32_T ) lq42vmb0rf * (
real32_T ) hjdzwdsemb ; bzay4rc4o2 = de3g0eec4m + localP -> P_164 ; if (
bzay4rc4o2 > localP -> P_31 ) { localB -> fpekvbmxwa = localP -> P_165 ; }
else { localB -> fpekvbmxwa = bzay4rc4o2 ; } localB -> cy55xte2zg_guugdwf2m3
[ 0 ] = localB -> nw12b21b42_llw0u2ae0v [ 0 ] ; localB ->
cy55xte2zg_guugdwf2m3 [ 1 ] = localB -> nw12b21b42_llw0u2ae0v [ 1 ] ; localB
-> b5vwzreuo4_idx_0 = localP -> P_146 [ 0 ] * localB -> cy55xte2zg_guugdwf2m3
[ 0 ] + localP -> P_146 [ 2 ] * localB -> cy55xte2zg_guugdwf2m3 [ 1 ] ;
localB -> ceqpqrxfmi_ldqodwenvz = localP -> P_146 [ 1 ] * localB ->
cy55xte2zg_guugdwf2m3 [ 0 ] + localP -> P_146 [ 3 ] * localB ->
cy55xte2zg_guugdwf2m3 [ 1 ] ; localB -> nw12b21b42_llw0u2ae0v [ 0 ] = localB
-> bbwy42xxao [ 0 ] ; localB -> nw12b21b42_llw0u2ae0v [ 1 ] = localB ->
bbwy42xxao [ 1 ] ; localB -> ciysnkgium_ppxrqq0gsf [ 0 ] = localP -> P_147 [
0 ] * localB -> bbwy42xxao [ 0 ] + localP -> P_147 [ 2 ] * localB ->
bbwy42xxao [ 1 ] ; localB -> oxxshm0p0o_idx_1 = localP -> P_147 [ 1 ] *
localB -> bbwy42xxao [ 0 ] + localP -> P_147 [ 3 ] * localB -> bbwy42xxao [ 1
] ; byi5lgnzr5 = dk05t4kqcv ; if ( byi5lgnzr5 ) { if ( ! localDW ->
bgpppixzwr ) { if ( rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart (
accn4cnket ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket ->
_mdlRefSfcnS ) ; } localDW -> bgpppixzwr = true ; } localB ->
osbuvwrg2r_idx_1 -= ( localP -> P_148 [ 0 ] * localB -> cy55xte2zg_guugdwf2m3
[ 0 ] + localP -> P_148 [ 2 ] * localB -> cy55xte2zg_guugdwf2m3 [ 1 ] ) + (
localP -> P_149 [ 0 ] * localB -> nw12b21b42_llw0u2ae0v [ 0 ] + localP ->
P_149 [ 2 ] * localB -> nw12b21b42_llw0u2ae0v [ 1 ] ) ; fggzgj03gr_idx_1 -= (
localP -> P_148 [ 1 ] * localB -> cy55xte2zg_guugdwf2m3 [ 0 ] + localP ->
P_148 [ 3 ] * localB -> cy55xte2zg_guugdwf2m3 [ 1 ] ) + ( localP -> P_149 [ 1
] * localB -> nw12b21b42_llw0u2ae0v [ 0 ] + localP -> P_149 [ 3 ] * localB ->
nw12b21b42_llw0u2ae0v [ 1 ] ) ; localB -> cfcvjoerpa [ 0 ] = 0.0F ; localB ->
cfcvjoerpa [ 0 ] += localB -> oaczprok10 [ 0 ] * localB -> osbuvwrg2r_idx_1 ;
localB -> cfcvjoerpa [ 0 ] += localB -> oaczprok10 [ 2 ] * fggzgj03gr_idx_1 ;
localB -> cfcvjoerpa [ 1 ] = 0.0F ; localB -> cfcvjoerpa [ 1 ] += localB ->
oaczprok10 [ 1 ] * localB -> osbuvwrg2r_idx_1 ; localB -> cfcvjoerpa [ 1 ] +=
localB -> oaczprok10 [ 3 ] * fggzgj03gr_idx_1 ; srUpdateBC ( localDW ->
hihnlferdi ) ; } else { if ( localDW -> bgpppixzwr ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> cfcvjoerpa [ 0 ] = localP -> P_90 ; localB -> cfcvjoerpa [ 1 ] =
localP -> P_90 ; localDW -> bgpppixzwr = false ; } } localB -> ee2t4z12sj [ 0
] = ( localB -> ciysnkgium_ppxrqq0gsf [ 0 ] + localB -> b5vwzreuo4_idx_0 ) +
localB -> cfcvjoerpa [ 0 ] ; localB -> ee2t4z12sj [ 1 ] = ( localB ->
oxxshm0p0o_idx_1 + localB -> ceqpqrxfmi_ldqodwenvz ) + localB -> cfcvjoerpa [
1 ] ; muSingleScalarSinCos ( localB -> octkfvursp [ 0 ] , & localB ->
ceqpqrxfmi_ldqodwenvz , & localB -> h4jvvstx1t_idx_0 ) ; muSingleScalarSinCos
( localB -> octkfvursp [ 1 ] , & ks0vnqom2i_idx_1 , & localB ->
h4jvvstx1t_idx_1 ) ; muSingleScalarSinCos ( localB -> octkfvursp [ 2 ] , &
ks0vnqom2i_idx_2 , & h4jvvstx1t_idx_2 ) ; localB -> grhszs3sjk_kkiq3xxxve [ 0
] = localB -> h4jvvstx1t_idx_1 * localB -> h4jvvstx1t_idx_0 ; localB ->
osbuvwrg2r_idx_2 = ks0vnqom2i_idx_2 * ks0vnqom2i_idx_1 ; localB ->
grhszs3sjk_kkiq3xxxve [ 1 ] = localB -> osbuvwrg2r_idx_2 * localB ->
h4jvvstx1t_idx_0 - h4jvvstx1t_idx_2 * localB -> ceqpqrxfmi_ldqodwenvz ;
localB -> cgkzo2biyi_dypejvacrn = h4jvvstx1t_idx_2 * ks0vnqom2i_idx_1 ;
localB -> grhszs3sjk_kkiq3xxxve [ 2 ] = localB -> cgkzo2biyi_dypejvacrn *
localB -> h4jvvstx1t_idx_0 + ks0vnqom2i_idx_2 * localB ->
ceqpqrxfmi_ldqodwenvz ; localB -> grhszs3sjk_kkiq3xxxve [ 3 ] = localB ->
h4jvvstx1t_idx_1 * localB -> ceqpqrxfmi_ldqodwenvz ; localB ->
grhszs3sjk_kkiq3xxxve [ 4 ] = localB -> osbuvwrg2r_idx_2 * localB ->
ceqpqrxfmi_ldqodwenvz + h4jvvstx1t_idx_2 * localB -> h4jvvstx1t_idx_0 ;
localB -> grhszs3sjk_kkiq3xxxve [ 5 ] = localB -> cgkzo2biyi_dypejvacrn *
localB -> ceqpqrxfmi_ldqodwenvz - ks0vnqom2i_idx_2 * localB ->
h4jvvstx1t_idx_0 ; localB -> grhszs3sjk_kkiq3xxxve [ 6 ] = - ks0vnqom2i_idx_1
; localB -> grhszs3sjk_kkiq3xxxve [ 7 ] = ks0vnqom2i_idx_2 * localB ->
h4jvvstx1t_idx_1 ; localB -> grhszs3sjk_kkiq3xxxve [ 8 ] = h4jvvstx1t_idx_2 *
localB -> h4jvvstx1t_idx_1 ; for ( localB -> uIdx = 0 ; localB -> uIdx < 3 ;
localB -> uIdx ++ ) { localB -> kynsre5lf4 [ localB -> uIdx ] = 0.0F ; localB
-> kynsre5lf4 [ localB -> uIdx ] += localB -> grhszs3sjk_kkiq3xxxve [ 3 *
localB -> uIdx ] * localB -> i53pibnrls [ 0 ] ; localB -> kynsre5lf4 [ localB
-> uIdx ] += localB -> grhszs3sjk_kkiq3xxxve [ 3 * localB -> uIdx + 1 ] *
localB -> i53pibnrls [ 1 ] ; localB -> kynsre5lf4 [ localB -> uIdx ] +=
localB -> grhszs3sjk_kkiq3xxxve [ 3 * localB -> uIdx + 2 ] * ( real32_T )
localB -> grhszs3sjk_cv5hdgrwft [ 2 ] ; } } void otjykwnhb3TID2 ( eo4bbte2ey
* localB , nu4qaxumex * localP ) { real_T cwa3qsqlzc ; real32_T ibcxb4vraw [
4 ] ; real32_T jlkj44p0p4 ; real32_T c4qqjwesre [ 4 ] ; real32_T moc314fiba [
4 ] ; memcpy ( & localB -> a1bbiq2a3a [ 0 ] , & localP -> P_142 [ 0 ] ,
sizeof ( real32_T ) << 4U ) ; localB -> hvdur1yjwa = localP -> P_52 - localP
-> P_53 ; localB -> h2ctrfi3m4 [ 0 ] = localP -> P_60 [ 0 ] ; localB ->
h2ctrfi3m4 [ 1 ] = localP -> P_60 [ 1 ] ; localB -> lxqvlboqdo [ 0 ] = localP
-> P_61 [ 0 ] ; localB -> lxqvlboqdo [ 1 ] = localP -> P_61 [ 1 ] ;
cwa3qsqlzc = 0.0 ; localB -> awcyzczet0_bhxxfovxdy [ 0 ] = localP -> P_59 [ 0
] ; localB -> awcyzczet0_bhxxfovxdy [ 1 ] = localP -> P_59 [ 1 ] ; localB ->
awcyzczet0_bhxxfovxdy [ 2 ] = localP -> P_59 [ 2 ] ; localB ->
awcyzczet0_bhxxfovxdy [ 3 ] = localP -> P_59 [ 3 ] ; ibcxb4vraw [ 0 ] = (
real32_T ) localP -> P_63 [ 0 ] ; ibcxb4vraw [ 1 ] = ( real32_T ) localP ->
P_63 [ 1 ] ; ibcxb4vraw [ 2 ] = ( real32_T ) localP -> P_63 [ 2 ] ;
ibcxb4vraw [ 3 ] = ( real32_T ) localP -> P_63 [ 3 ] ; localB -> fnzhxbxjia [
0 ] = localP -> P_69 [ 0 ] ; localB -> fnzhxbxjia [ 1 ] = localP -> P_69 [ 1
] ; localB -> oaczprok10 [ 0 ] = ( real32_T ) localP -> P_73 [ 0 ] ; localB
-> oaczprok10 [ 1 ] = ( real32_T ) localP -> P_73 [ 1 ] ; localB ->
oaczprok10 [ 2 ] = ( real32_T ) localP -> P_73 [ 2 ] ; localB -> oaczprok10 [
3 ] = ( real32_T ) localP -> P_73 [ 3 ] ; localB -> kyi2cghtbd [ 0 ] = (
real32_T ) localP -> P_74 [ 0 ] ; localB -> kyi2cghtbd [ 1 ] = ( real32_T )
localP -> P_74 [ 1 ] ; localB -> kyi2cghtbd [ 2 ] = ( real32_T ) localP ->
P_74 [ 2 ] ; localB -> kyi2cghtbd [ 3 ] = ( real32_T ) localP -> P_74 [ 3 ] ;
jlkj44p0p4 = 0.0F ; c4qqjwesre [ 0 ] = ( real32_T ) localP -> P_72 [ 0 ] ;
c4qqjwesre [ 1 ] = ( real32_T ) localP -> P_72 [ 1 ] ; c4qqjwesre [ 2 ] = (
real32_T ) localP -> P_72 [ 2 ] ; c4qqjwesre [ 3 ] = ( real32_T ) localP ->
P_72 [ 3 ] ; moc314fiba [ 0 ] = localP -> P_150 [ 0 ] ; moc314fiba [ 1 ] =
localP -> P_150 [ 1 ] ; moc314fiba [ 2 ] = localP -> P_150 [ 2 ] ; moc314fiba
[ 3 ] = localP -> P_150 [ 3 ] ; localB -> b5osnmhsrd [ 0 ] = localP -> P_156
[ 0 ] ; localB -> b5osnmhsrd [ 1 ] = localP -> P_156 [ 1 ] ; } void
lsjhvu4egy ( eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP
) { int32_T memOffset ; int32_T i ; localDW -> ii2o5s5qnf = ( int8_T ) localP
-> P_167 ; localDW -> mck2owxrk2 = localB -> ernp5tvitp [ 0 ] ; localDW ->
ozjz0fr0k4 = 0U ; localDW -> jxg1zvdttz [ 0 ] += localP -> P_92 * localB ->
kynsre5lf4 [ 0 ] ; localDW -> etwz51o21c [ 0 ] = localB -> j5wzgpzqi4 [ 0 ] ;
localDW -> kgows215bs [ 2 ] = localDW -> kgows215bs [ 1 ] ; localDW ->
c4t5e3w5ek [ 2 ] = localDW -> c4t5e3w5ek [ 1 ] ; localDW -> jxg1zvdttz [ 1 ]
+= localP -> P_92 * localB -> kynsre5lf4 [ 1 ] ; localDW -> etwz51o21c [ 1 ]
= localB -> j5wzgpzqi4 [ 1 ] ; localDW -> kgows215bs [ 1 ] = localDW ->
kgows215bs [ 0 ] ; localDW -> c4t5e3w5ek [ 1 ] = localDW -> c4t5e3w5ek [ 0 ]
; localDW -> kgows215bs [ 0 ] = localDW -> ik5zcuhoy3 ; localDW -> c4t5e3w5ek
[ 0 ] = localDW -> fl2edockfe ; localDW -> lfi3mnae2m [ 0 ] = localB ->
octkfvursp [ 0 ] ; localDW -> lfi3mnae2m [ 1 ] = localB -> octkfvursp [ 1 ] ;
localDW -> lfi3mnae2m [ 2 ] = localB -> octkfvursp [ 2 ] ; localDW ->
liybiw1jbg [ 4 ] = localDW -> liybiw1jbg [ 3 ] ; localDW -> liybiw1jbg [ 3 ]
= localDW -> liybiw1jbg [ 2 ] ; localDW -> liybiw1jbg [ 2 ] = localDW ->
liybiw1jbg [ 1 ] ; localDW -> liybiw1jbg [ 1 ] = localDW -> liybiw1jbg [ 0 ]
; localDW -> liybiw1jbg [ 0 ] = localDW -> lpva1qajzk ; localDW -> cfcgwprtdx
-- ; if ( localDW -> cfcgwprtdx < 0 ) { localDW -> cfcgwprtdx = 4 ; } localDW
-> nbbc5odoq4 [ localDW -> cfcgwprtdx ] = localB -> djn3bbsoat [ 0 ] ;
localDW -> nbbc5odoq4 [ localDW -> cfcgwprtdx + 5 ] = localB -> djn3bbsoat [
1 ] ; localDW -> nbbc5odoq4 [ localDW -> cfcgwprtdx + 10 ] = localB ->
djn3bbsoat [ 2 ] ; localDW -> npsllq52wf = localB -> fpekvbmxwa ; localDW ->
pvn1aiza5a = 0U ; localDW -> hmetbef2mf = localB -> pcafmpcl4b ; localDW ->
me4j0lrjd2 = localB -> ftda3noqkg ; localDW -> mb3yoxlyu3 = localB ->
nkkovac5ti ; for ( i = 0 ; i < 2 ; i ++ ) { localDW -> kzeijhdtif [ i ] =
localB -> ee2t4z12sj [ i ] ; memOffset = i * 5 ; localDW -> heeedoxzle [
memOffset + 4 ] = localDW -> heeedoxzle [ memOffset + 3 ] ; localDW ->
heeedoxzle [ memOffset + 3 ] = localDW -> heeedoxzle [ memOffset + 2 ] ;
localDW -> heeedoxzle [ memOffset + 2 ] = localDW -> heeedoxzle [ memOffset +
1 ] ; localDW -> heeedoxzle [ memOffset + 1 ] = localDW -> heeedoxzle [
memOffset ] ; localDW -> heeedoxzle [ memOffset ] = localDW -> dhhdwwczx2 [ i
] ; localDW -> gqxdiwstsm [ i ] = localB -> kitmhlyutx [ i ] ; localDW ->
a3uar2xrsb [ i ] = localB -> i53pibnrls [ i ] ; localDW -> lw3rw5s0ye [ i ] =
localB -> i53pibnrls [ i ] ; localDW -> cosb2ibhn3 [ i ] = localB ->
k1lgyzog01 [ i ] ; localDW -> fuo05buemm [ i ] += localP -> P_119 * localB ->
jl4zglnkcz [ i ] ; if ( localDW -> fuo05buemm [ i ] >= localP -> P_121 ) {
localDW -> fuo05buemm [ i ] = localP -> P_121 ; } else { if ( localDW ->
fuo05buemm [ i ] <= localP -> P_122 ) { localDW -> fuo05buemm [ i ] = localP
-> P_122 ; } } } localDW -> i13qoukcsn = localB -> nir2sesw4o ; localDW ->
ppp4ajc3p1 += localP -> P_126 * localB -> cdicpgn145 ; if ( localDW ->
ppp4ajc3p1 >= localP -> P_128 ) { localDW -> ppp4ajc3p1 = localP -> P_128 ; }
else { if ( localDW -> ppp4ajc3p1 <= localP -> P_129 ) { localDW ->
ppp4ajc3p1 = localP -> P_129 ; } } localDW -> gafzug4yea = ( int8_T ) localB
-> f25x251bac ; localDW -> dxm3w2i52x = localB -> gfrwlpjnn2 ; localDW ->
bw2ribqmwm = localB -> cyov5ky1ov ; } static boolean_T e4uq03sdk2 (
bjqsgn0csy * obj ) { boolean_T anyInputSizeChanged ; int16_T inSize [ 8 ] ;
int32_T b_k ; boolean_T exitg1 ; anyInputSizeChanged = false ; inSize [ 0 ] =
4 ; inSize [ 1 ] = 9600 ; for ( b_k = 0 ; b_k < 6 ; b_k ++ ) { inSize [ b_k +
2 ] = 1 ; } b_k = 0 ; exitg1 = false ; while ( ( ! exitg1 ) && ( b_k < 8 ) )
{ if ( obj -> inputVarSize . f1 [ b_k ] != ( uint32_T ) inSize [ b_k ] ) {
anyInputSizeChanged = true ; for ( b_k = 0 ; b_k < 8 ; b_k ++ ) { obj ->
inputVarSize . f1 [ b_k ] = ( uint32_T ) inSize [ b_k ] ; } exitg1 = true ; }
else { b_k ++ ; } } return anyInputSizeChanged ; } static void llg2sedmqv (
uint8_T varargout_1 [ 19200 ] , uint8_T varargout_2 [ 19200 ] , uint8_T
varargout_3 [ 19200 ] ) { memset ( & varargout_1 [ 0 ] , 0 , 19200U * sizeof
( uint8_T ) ) ; memset ( & varargout_2 [ 0 ] , 0 , 19200U * sizeof ( uint8_T
) ) ; memset ( & varargout_3 [ 0 ] , 0 , 19200U * sizeof ( uint8_T ) ) ; }
static void bljpfp3pka ( bjqsgn0csy * obj , uint8_T varargout_1 [ 19200 ] ,
uint8_T varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) { e4uq03sdk2
( obj ) ; llg2sedmqv ( varargout_1 , varargout_2 , varargout_3 ) ; } void
ha1ipjbq54 ( uint8_T * o3vpgniqky ) { int32_T i ; for ( i = 0 ; i < 19200 ; i
++ ) { dqykr4eggmg . oq44mkeutp [ i ] = b1hr2q0zjh . P_1 ; } dqykr4eggmg .
fb0f52aifb = 0 ; ic5jb3movn ( & ksm0js2nhsy . otjykwnhb3s , & dqykr4eggmg .
otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; * o3vpgniqky = ksm0js2nhsy .
otjykwnhb3s . i0mkwvniar ; } void gwlyno50ln ( void ) { int32_T i ; for ( i =
0 ; i < 19200 ; i ++ ) { dqykr4eggmg . oq44mkeutp [ i ] = b1hr2q0zjh . P_1 ;
} dqykr4eggmg . fb0f52aifb = 0 ; bxsrqc204k ( & dqykr4eggmg . otjykwnhb3s , &
b1hr2q0zjh . otjykwnhb3s ) ; } void bog0frvixl ( void ) { kegjp2lgms ( &
ksm0js2nhsy . otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , & b1hr2q0zjh .
otjykwnhb3s ) ; } void k3yxem35zg ( void ) { int32_T i ; dqykr4eggmg .
jjrfotind4 = true ; dqykr4eggmg . l152eirbdu . isInitialized = 1 ;
dqykr4eggmg . l152eirbdu . inputVarSize . f1 [ 0 ] = 4U ; dqykr4eggmg .
l152eirbdu . inputVarSize . f1 [ 1 ] = 9600U ; for ( i = 0 ; i < 6 ; i ++ ) {
dqykr4eggmg . l152eirbdu . inputVarSize . f1 [ i + 2 ] = 1U ; } } void
flightControlSystemTID0 ( const CommandBus * iarztl0jur , const SensorsBus *
pxdb2gu5va , real32_T pikqq4svts [ 4 ] , uint8_T * o3vpgniqky ) { ipf5ube4r0
* const accn4cnket = & ( lhjbdsj2rj . rtm ) ; ksm0js2nhsy . i = dqykr4eggmg .
fb0f52aifb * 19200 ; for ( ksm0js2nhsy . i1 = 0 ; ksm0js2nhsy . i1 < 19200 ;
ksm0js2nhsy . i1 ++ ) { ksm0js2nhsy . jr5xpaibtu_mbvzarwird [ ksm0js2nhsy .
i1 ] = dqykr4eggmg . oq44mkeutp [ ksm0js2nhsy . i1 + ksm0js2nhsy . i ] ; }
otjykwnhb3 ( accn4cnket , iarztl0jur , pxdb2gu5va , ksm0js2nhsy .
jr5xpaibtu_mbvzarwird , & ksm0js2nhsy . otjykwnhb3s , & dqykr4eggmg .
otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; pikqq4svts [ 0 ] = ksm0js2nhsy .
otjykwnhb3s . dz0gwbmcjt [ 0 ] ; pikqq4svts [ 1 ] = ksm0js2nhsy . otjykwnhb3s
. dz0gwbmcjt [ 1 ] ; pikqq4svts [ 2 ] = ksm0js2nhsy . otjykwnhb3s .
dz0gwbmcjt [ 2 ] ; pikqq4svts [ 3 ] = ksm0js2nhsy . otjykwnhb3s . dz0gwbmcjt
[ 3 ] ; * o3vpgniqky = ksm0js2nhsy . otjykwnhb3s . i0mkwvniar ; } void
flightControlSystemTID1 ( void ) { int32_T i ; bljpfp3pka ( & dqykr4eggmg .
l152eirbdu , ksm0js2nhsy . b_varargout_1 , ksm0js2nhsy . b_varargout_2 ,
ksm0js2nhsy . b_varargout_3 ) ; for ( i = 0 ; i < 19200 ; i ++ ) {
ksm0js2nhsy . chvqnltnss_cl54gopm0x [ i ] = ( ( ksm0js2nhsy . b_varargout_1 [
i ] >= 151 ) && ( ksm0js2nhsy . b_varargout_2 [ i ] <= 107 ) && ( ksm0js2nhsy
. b_varargout_3 [ i ] <= 100 ) ) ; } for ( i = 0 ; i < 19200 ; i ++ ) {
dqykr4eggmg . oq44mkeutp [ i + ( dqykr4eggmg . fb0f52aifb == 0 ) * 19200 ] =
ksm0js2nhsy . chvqnltnss_cl54gopm0x [ i ] ; } dqykr4eggmg . fb0f52aifb = (
int8_T ) ( dqykr4eggmg . fb0f52aifb == 0 ) ; } void flightControlSystemTID2 (
void ) { otjykwnhb3TID2 ( & ksm0js2nhsy . otjykwnhb3s , & b1hr2q0zjh .
otjykwnhb3s ) ; } void pyvd4pdf3iTID0 ( void ) { lsjhvu4egy ( & ksm0js2nhsy .
otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; }
void pyvd4pdf3iTID1 ( void ) { } void pyvd4pdf3iTID2 ( void ) { } void
o2f5l50guo ( void ) { ipf5ube4r0 * const accn4cnket = & ( lhjbdsj2rj . rtm )
; if ( ! slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent (
accn4cnket -> _mdlRefSfcnS , "flightControlSystem" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void f4qzdbbxmw (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T
mdlref_TID2 , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) { ipf5ube4r0 * const accn4cnket = & ( lhjbdsj2rj . rtm ) ;
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; b1hr2q0zjh . otjykwnhb3s . P_37 =
rtMinusInf ; ( void ) memset ( ( void * ) accn4cnket , 0 , sizeof (
ipf5ube4r0 ) ) ; nmtwkzsqud [ 0 ] = mdlref_TID0 ; nmtwkzsqud [ 1 ] =
mdlref_TID1 ; nmtwkzsqud [ 2 ] = mdlref_TID2 ; accn4cnket -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( accn4cnket -> _mdlRefSfcnS , "flightControlSystem" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) & ksm0js2nhsy ) , 0 , sizeof ( ircitwx3zdm ) ) ; { int32_T i ; for ( i = 0
; i < 6 ; i ++ ) { ksm0js2nhsy . otjykwnhb3s . djn3bbsoat [ i ] = 0.0F ; }
for ( i = 0 ; i < 16 ; i ++ ) { ksm0js2nhsy . otjykwnhb3s . a1bbiq2a3a [ i ]
= 0.0F ; } ksm0js2nhsy . otjykwnhb3s . bnbzowcxmh = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . ernp5tvitp [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ernp5tvitp
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ftda3noqkg = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . nkkovac5ti = 0.0 ; ksm0js2nhsy . otjykwnhb3s . cyov5ky1ov = 0.0
; ksm0js2nhsy . otjykwnhb3s . nmdhai2lmc [ 0 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . nmdhai2lmc [ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . nmdhai2lmc
[ 2 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . j5wzgpzqi4 [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . j5wzgpzqi4 [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . hvdur1yjwa = 0.0 ; ksm0js2nhsy . otjykwnhb3s . h2ctrfi3m4 [ 0 ]
= 0.0 ; ksm0js2nhsy . otjykwnhb3s . h2ctrfi3m4 [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . lxqvlboqdo [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . lxqvlboqdo
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . fnzhxbxjia [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . fnzhxbxjia [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . ozbnyngphj [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ozbnyngphj
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . j42uqprebt [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . j42uqprebt [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . pcafmpcl4b = 0.0 ; ksm0js2nhsy . otjykwnhb3s . p5pzfnaiuu [ 0 ]
= 0.0F ; ksm0js2nhsy . otjykwnhb3s . p5pzfnaiuu [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . octkfvursp [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
octkfvursp [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . octkfvursp [ 2 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . enwpjq4sny [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . enwpjq4sny [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
enwpjq4sny [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . kitmhlyutx [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . kitmhlyutx [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . i53pibnrls [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
i53pibnrls [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . jl4zglnkcz [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . jl4zglnkcz [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . k1lgyzog01 [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
k1lgyzog01 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . cdicpgn145 = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . dz0gwbmcjt [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . dz0gwbmcjt [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
dz0gwbmcjt [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . dz0gwbmcjt [ 3 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . bbwy42xxao [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . bbwy42xxao [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
ee2t4z12sj [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . ee2t4z12sj [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . kynsre5lf4 [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . kynsre5lf4 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
kynsre5lf4 [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . oaczprok10 [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . oaczprok10 [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . oaczprok10 [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
oaczprok10 [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . kyi2cghtbd [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . kyi2cghtbd [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . kyi2cghtbd [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
kyi2cghtbd [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . b5osnmhsrd [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . b5osnmhsrd [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . bkehspj2gn [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
bkehspj2gn [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . cfcvjoerpa [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . cfcvjoerpa [ 1 ] = 0.0F ; } ( void ) memset ( (
void * ) & dqykr4eggmg , 0 , sizeof ( nllkaxiwhzw ) ) ; dqykr4eggmg .
otjykwnhb3s . mck2owxrk2 = 0.0 ; dqykr4eggmg . otjykwnhb3s . etwz51o21c [ 0 ]
= 0.0 ; dqykr4eggmg . otjykwnhb3s . etwz51o21c [ 1 ] = 0.0 ; dqykr4eggmg .
otjykwnhb3s . c4t5e3w5ek [ 0 ] = 0.0 ; dqykr4eggmg . otjykwnhb3s . c4t5e3w5ek
[ 1 ] = 0.0 ; dqykr4eggmg . otjykwnhb3s . c4t5e3w5ek [ 2 ] = 0.0 ;
dqykr4eggmg . otjykwnhb3s . hmetbef2mf = 0.0 ; dqykr4eggmg . otjykwnhb3s .
me4j0lrjd2 = 0.0 ; dqykr4eggmg . otjykwnhb3s . mb3yoxlyu3 = 0.0 ; dqykr4eggmg
. otjykwnhb3s . bw2ribqmwm = 0.0 ; dqykr4eggmg . otjykwnhb3s . fl2edockfe =
0.0 ; dqykr4eggmg . otjykwnhb3s . jxg1zvdttz [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . jxg1zvdttz [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
kgows215bs [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . kgows215bs [ 1 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . kgows215bs [ 2 ] = 0.0F ; { int32_T i ; for ( i
= 0 ; i < 5 ; i ++ ) { dqykr4eggmg . otjykwnhb3s . liybiw1jbg [ i ] = 0.0F ;
} } { int32_T i ; for ( i = 0 ; i < 15 ; i ++ ) { dqykr4eggmg . otjykwnhb3s .
nbbc5odoq4 [ i ] = 0.0F ; } } dqykr4eggmg . otjykwnhb3s . kzeijhdtif [ 0 ] =
0.0F ; dqykr4eggmg . otjykwnhb3s . kzeijhdtif [ 1 ] = 0.0F ; { int32_T i ;
for ( i = 0 ; i < 10 ; i ++ ) { dqykr4eggmg . otjykwnhb3s . heeedoxzle [ i ]
= 0.0F ; } } dqykr4eggmg . otjykwnhb3s . gqxdiwstsm [ 0 ] = 0.0F ;
dqykr4eggmg . otjykwnhb3s . gqxdiwstsm [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . a3uar2xrsb [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
a3uar2xrsb [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . lw3rw5s0ye [ 0 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . lw3rw5s0ye [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . cosb2ibhn3 [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
cosb2ibhn3 [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . fuo05buemm [ 0 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . fuo05buemm [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . ppp4ajc3p1 = 0.0F ; dqykr4eggmg . otjykwnhb3s . ik5zcuhoy3 =
0.0F ; dqykr4eggmg . otjykwnhb3s . lfi3mnae2m [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . lfi3mnae2m [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
lfi3mnae2m [ 2 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . lpva1qajzk = 0.0F ;
dqykr4eggmg . otjykwnhb3s . dhhdwwczx2 [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . dhhdwwczx2 [ 1 ] = 0.0F ;
flightControlSystem_InitializeDataMapInfo ( accn4cnket , sysRanPtr ,
contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && ( rt_ChildPath != ( NULL
) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI , rt_ChildMMIIdx , & (
accn4cnket -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath ( accn4cnket ->
DataMapInfo . mmi , rt_ChildPath ) ; rtwCAPI_MMISetContStateStartIndex (
accn4cnket -> DataMapInfo . mmi , rt_CSTATEIdx ) ; } } void
mr_flightControlSystem_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo
= false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ;
if ( regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo (
mdlRefSfcnS , modelName , rtMdlInfo_flightControlSystem , 133 ) ; * retVal =
1 ; } static void mr_flightControlSystem_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_flightControlSystem_cacheDataAsMxArray ( mxArray * destArray ,
mwIndex i , int j , const void * srcData , size_t numBytes ) { mxArray *
newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void mr_flightControlSystem_restoreDataFromMxArray
( void * destData , const mxArray * srcArray , mwIndex i , int j , size_t
numBytes ) ; static void mr_flightControlSystem_restoreDataFromMxArray ( void
* destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes )
{ memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_flightControlSystem_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) ; static void
mr_flightControlSystem_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_flightControlSystem_extractBitFieldFromMxArray ( const mxArray * srcArray
, mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_flightControlSystem_extractBitFieldFromMxArray ( const mxArray * srcArray
, mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_flightControlSystem_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_flightControlSystem_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_flightControlSystem_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_flightControlSystem_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_flightControlSystem_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "ksm0js2nhsy" , "dqykr4eggmg" ,
"NULL_PrevZCX" , } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 ,
ssDWFieldNames ) ; mr_flightControlSystem_cacheDataAsMxArray ( ssDW , 0 , 0 ,
& ( ksm0js2nhsy ) , sizeof ( ksm0js2nhsy ) ) ; { static const char *
rtdwDataFieldNames [ 53 ] = { "dqykr4eggmg.l152eirbdu" ,
"dqykr4eggmg.fb0f52aifb" , "dqykr4eggmg.oq44mkeutp" ,
"dqykr4eggmg.jjrfotind4" , "dqykr4eggmg.otjykwnhb3s.mck2owxrk2" ,
"dqykr4eggmg.otjykwnhb3s.etwz51o21c" , "dqykr4eggmg.otjykwnhb3s.c4t5e3w5ek" ,
"dqykr4eggmg.otjykwnhb3s.hmetbef2mf" , "dqykr4eggmg.otjykwnhb3s.me4j0lrjd2" ,
"dqykr4eggmg.otjykwnhb3s.mb3yoxlyu3" , "dqykr4eggmg.otjykwnhb3s.bw2ribqmwm" ,
"dqykr4eggmg.otjykwnhb3s.fl2edockfe" , "dqykr4eggmg.otjykwnhb3s.jxg1zvdttz" ,
"dqykr4eggmg.otjykwnhb3s.kgows215bs" , "dqykr4eggmg.otjykwnhb3s.liybiw1jbg" ,
"dqykr4eggmg.otjykwnhb3s.nbbc5odoq4" , "dqykr4eggmg.otjykwnhb3s.kzeijhdtif" ,
"dqykr4eggmg.otjykwnhb3s.heeedoxzle" , "dqykr4eggmg.otjykwnhb3s.gqxdiwstsm" ,
"dqykr4eggmg.otjykwnhb3s.a3uar2xrsb" , "dqykr4eggmg.otjykwnhb3s.lw3rw5s0ye" ,
"dqykr4eggmg.otjykwnhb3s.cosb2ibhn3" , "dqykr4eggmg.otjykwnhb3s.fuo05buemm" ,
"dqykr4eggmg.otjykwnhb3s.ppp4ajc3p1" , "dqykr4eggmg.otjykwnhb3s.cfcgwprtdx" ,
"dqykr4eggmg.otjykwnhb3s.npsllq52wf" , "dqykr4eggmg.otjykwnhb3s.i13qoukcsn" ,
"dqykr4eggmg.otjykwnhb3s.dxm3w2i52x" , "dqykr4eggmg.otjykwnhb3s.ik5zcuhoy3" ,
"dqykr4eggmg.otjykwnhb3s.lfi3mnae2m" , "dqykr4eggmg.otjykwnhb3s.lpva1qajzk" ,
"dqykr4eggmg.otjykwnhb3s.dhhdwwczx2" , "dqykr4eggmg.otjykwnhb3s.ii2o5s5qnf" ,
"dqykr4eggmg.otjykwnhb3s.gafzug4yea" , "dqykr4eggmg.otjykwnhb3s.nuogwfijir" ,
"dqykr4eggmg.otjykwnhb3s.hihnlferdi" , "dqykr4eggmg.otjykwnhb3s.pxamy50saq" ,
"dqykr4eggmg.otjykwnhb3s.btfjf5acqg" , "dqykr4eggmg.otjykwnhb3s.oa1muqt4on" ,
"dqykr4eggmg.otjykwnhb3s.h0cudiu0ft" , "dqykr4eggmg.otjykwnhb3s.iu11iwpdyn" ,
"dqykr4eggmg.otjykwnhb3s.b3ewiobpsi" , "dqykr4eggmg.otjykwnhb3s.ozjz0fr0k4" ,
"dqykr4eggmg.otjykwnhb3s.pvn1aiza5a" , "dqykr4eggmg.otjykwnhb3s.j20mj4ai3a" ,
"dqykr4eggmg.otjykwnhb3s.bgpppixzwr" , "dqykr4eggmg.otjykwnhb3s.cmab1dak24" ,
"dqykr4eggmg.otjykwnhb3s.jtnjtissuf" ,
"dqykr4eggmg.otjykwnhb3s.ciy1c2o0rv.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.jvbbqhrajh.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.clwiujjdqo.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.acfz1zxm4t.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.ghadbep3bbv.fau3qf03xm" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 53 , rtdwDataFieldNames ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 0 , & (
dqykr4eggmg . l152eirbdu ) , sizeof ( dqykr4eggmg . l152eirbdu ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 1 , & (
dqykr4eggmg . fb0f52aifb ) , sizeof ( dqykr4eggmg . fb0f52aifb ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 2 , & (
dqykr4eggmg . oq44mkeutp ) , sizeof ( dqykr4eggmg . oq44mkeutp ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 3 , & (
dqykr4eggmg . jjrfotind4 ) , sizeof ( dqykr4eggmg . jjrfotind4 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 4 , & (
dqykr4eggmg . otjykwnhb3s . mck2owxrk2 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mck2owxrk2 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
5 , & ( dqykr4eggmg . otjykwnhb3s . etwz51o21c ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . etwz51o21c ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 6 , & ( dqykr4eggmg . otjykwnhb3s . c4t5e3w5ek ) , sizeof (
dqykr4eggmg . otjykwnhb3s . c4t5e3w5ek ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 7 , & (
dqykr4eggmg . otjykwnhb3s . hmetbef2mf ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. hmetbef2mf ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
8 , & ( dqykr4eggmg . otjykwnhb3s . me4j0lrjd2 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . me4j0lrjd2 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 9 , & ( dqykr4eggmg . otjykwnhb3s . mb3yoxlyu3 ) , sizeof (
dqykr4eggmg . otjykwnhb3s . mb3yoxlyu3 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 10 , & (
dqykr4eggmg . otjykwnhb3s . bw2ribqmwm ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. bw2ribqmwm ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
11 , & ( dqykr4eggmg . otjykwnhb3s . fl2edockfe ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . fl2edockfe ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 12 , & ( dqykr4eggmg . otjykwnhb3s . jxg1zvdttz ) , sizeof (
dqykr4eggmg . otjykwnhb3s . jxg1zvdttz ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 13 , & (
dqykr4eggmg . otjykwnhb3s . kgows215bs ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. kgows215bs ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
14 , & ( dqykr4eggmg . otjykwnhb3s . liybiw1jbg ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . liybiw1jbg ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 15 , & ( dqykr4eggmg . otjykwnhb3s . nbbc5odoq4 ) , sizeof (
dqykr4eggmg . otjykwnhb3s . nbbc5odoq4 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 16 , & (
dqykr4eggmg . otjykwnhb3s . kzeijhdtif ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. kzeijhdtif ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
17 , & ( dqykr4eggmg . otjykwnhb3s . heeedoxzle ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . heeedoxzle ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 18 , & ( dqykr4eggmg . otjykwnhb3s . gqxdiwstsm ) , sizeof (
dqykr4eggmg . otjykwnhb3s . gqxdiwstsm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 19 , & (
dqykr4eggmg . otjykwnhb3s . a3uar2xrsb ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. a3uar2xrsb ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
20 , & ( dqykr4eggmg . otjykwnhb3s . lw3rw5s0ye ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . lw3rw5s0ye ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 21 , & ( dqykr4eggmg . otjykwnhb3s . cosb2ibhn3 ) , sizeof (
dqykr4eggmg . otjykwnhb3s . cosb2ibhn3 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 22 , & (
dqykr4eggmg . otjykwnhb3s . fuo05buemm ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. fuo05buemm ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
23 , & ( dqykr4eggmg . otjykwnhb3s . ppp4ajc3p1 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . ppp4ajc3p1 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 24 , & ( dqykr4eggmg . otjykwnhb3s . cfcgwprtdx ) , sizeof (
dqykr4eggmg . otjykwnhb3s . cfcgwprtdx ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 25 , & (
dqykr4eggmg . otjykwnhb3s . npsllq52wf ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. npsllq52wf ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
26 , & ( dqykr4eggmg . otjykwnhb3s . i13qoukcsn ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . i13qoukcsn ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 27 , & ( dqykr4eggmg . otjykwnhb3s . dxm3w2i52x ) , sizeof (
dqykr4eggmg . otjykwnhb3s . dxm3w2i52x ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 28 , & (
dqykr4eggmg . otjykwnhb3s . ik5zcuhoy3 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. ik5zcuhoy3 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
29 , & ( dqykr4eggmg . otjykwnhb3s . lfi3mnae2m ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . lfi3mnae2m ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 30 , & ( dqykr4eggmg . otjykwnhb3s . lpva1qajzk ) , sizeof (
dqykr4eggmg . otjykwnhb3s . lpva1qajzk ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 31 , & (
dqykr4eggmg . otjykwnhb3s . dhhdwwczx2 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. dhhdwwczx2 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
32 , & ( dqykr4eggmg . otjykwnhb3s . ii2o5s5qnf ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . ii2o5s5qnf ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 33 , & ( dqykr4eggmg . otjykwnhb3s . gafzug4yea ) , sizeof (
dqykr4eggmg . otjykwnhb3s . gafzug4yea ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 34 , & (
dqykr4eggmg . otjykwnhb3s . nuogwfijir ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. nuogwfijir ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
35 , & ( dqykr4eggmg . otjykwnhb3s . hihnlferdi ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . hihnlferdi ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 36 , & ( dqykr4eggmg . otjykwnhb3s . pxamy50saq ) , sizeof (
dqykr4eggmg . otjykwnhb3s . pxamy50saq ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 37 , & (
dqykr4eggmg . otjykwnhb3s . btfjf5acqg ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. btfjf5acqg ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
38 , & ( dqykr4eggmg . otjykwnhb3s . oa1muqt4on ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . oa1muqt4on ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 39 , & ( dqykr4eggmg . otjykwnhb3s . h0cudiu0ft ) , sizeof (
dqykr4eggmg . otjykwnhb3s . h0cudiu0ft ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 40 , & (
dqykr4eggmg . otjykwnhb3s . iu11iwpdyn ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. iu11iwpdyn ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
41 , & ( dqykr4eggmg . otjykwnhb3s . b3ewiobpsi ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . b3ewiobpsi ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 42 , & ( dqykr4eggmg . otjykwnhb3s . ozjz0fr0k4 ) , sizeof (
dqykr4eggmg . otjykwnhb3s . ozjz0fr0k4 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 43 , & (
dqykr4eggmg . otjykwnhb3s . pvn1aiza5a ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. pvn1aiza5a ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
44 , & ( dqykr4eggmg . otjykwnhb3s . j20mj4ai3a ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . j20mj4ai3a ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 45 , & ( dqykr4eggmg . otjykwnhb3s . bgpppixzwr ) , sizeof (
dqykr4eggmg . otjykwnhb3s . bgpppixzwr ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 46 , & (
dqykr4eggmg . otjykwnhb3s . cmab1dak24 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. cmab1dak24 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
47 , & ( dqykr4eggmg . otjykwnhb3s . jtnjtissuf ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . jtnjtissuf ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 48 , & ( dqykr4eggmg . otjykwnhb3s . ciy1c2o0rv . fau3qf03xm )
, sizeof ( dqykr4eggmg . otjykwnhb3s . ciy1c2o0rv . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 49 , & (
dqykr4eggmg . otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 50 , & (
dqykr4eggmg . otjykwnhb3s . clwiujjdqo . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . clwiujjdqo . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 51 , & (
dqykr4eggmg . otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 52 , & (
dqykr4eggmg . otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) ) ; mxSetFieldByNumber ( ssDW , 0
, 1 , rtdwData ) ; } return ssDW ; } void mr_flightControlSystem_SetDWork (
const mxArray * ssDW ) { ( void ) ssDW ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( ksm0js2nhsy ) , ssDW , 0
, 0 , sizeof ( ksm0js2nhsy ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . l152eirbdu
) , rtdwData , 0 , 0 , sizeof ( dqykr4eggmg . l152eirbdu ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . fb0f52aifb
) , rtdwData , 0 , 1 , sizeof ( dqykr4eggmg . fb0f52aifb ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . oq44mkeutp
) , rtdwData , 0 , 2 , sizeof ( dqykr4eggmg . oq44mkeutp ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . jjrfotind4
) , rtdwData , 0 , 3 , sizeof ( dqykr4eggmg . jjrfotind4 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mck2owxrk2 ) , rtdwData , 0 , 4 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mck2owxrk2 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . etwz51o21c ) , rtdwData , 0 , 5 , sizeof (
dqykr4eggmg . otjykwnhb3s . etwz51o21c ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. c4t5e3w5ek ) , rtdwData , 0 , 6 , sizeof ( dqykr4eggmg . otjykwnhb3s .
c4t5e3w5ek ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . hmetbef2mf ) , rtdwData , 0 , 7 , sizeof (
dqykr4eggmg . otjykwnhb3s . hmetbef2mf ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. me4j0lrjd2 ) , rtdwData , 0 , 8 , sizeof ( dqykr4eggmg . otjykwnhb3s .
me4j0lrjd2 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . mb3yoxlyu3 ) , rtdwData , 0 , 9 , sizeof (
dqykr4eggmg . otjykwnhb3s . mb3yoxlyu3 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. bw2ribqmwm ) , rtdwData , 0 , 10 , sizeof ( dqykr4eggmg . otjykwnhb3s .
bw2ribqmwm ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . fl2edockfe ) , rtdwData , 0 , 11 , sizeof (
dqykr4eggmg . otjykwnhb3s . fl2edockfe ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. jxg1zvdttz ) , rtdwData , 0 , 12 , sizeof ( dqykr4eggmg . otjykwnhb3s .
jxg1zvdttz ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . kgows215bs ) , rtdwData , 0 , 13 , sizeof (
dqykr4eggmg . otjykwnhb3s . kgows215bs ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. liybiw1jbg ) , rtdwData , 0 , 14 , sizeof ( dqykr4eggmg . otjykwnhb3s .
liybiw1jbg ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . nbbc5odoq4 ) , rtdwData , 0 , 15 , sizeof (
dqykr4eggmg . otjykwnhb3s . nbbc5odoq4 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. kzeijhdtif ) , rtdwData , 0 , 16 , sizeof ( dqykr4eggmg . otjykwnhb3s .
kzeijhdtif ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . heeedoxzle ) , rtdwData , 0 , 17 , sizeof (
dqykr4eggmg . otjykwnhb3s . heeedoxzle ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. gqxdiwstsm ) , rtdwData , 0 , 18 , sizeof ( dqykr4eggmg . otjykwnhb3s .
gqxdiwstsm ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . a3uar2xrsb ) , rtdwData , 0 , 19 , sizeof (
dqykr4eggmg . otjykwnhb3s . a3uar2xrsb ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. lw3rw5s0ye ) , rtdwData , 0 , 20 , sizeof ( dqykr4eggmg . otjykwnhb3s .
lw3rw5s0ye ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . cosb2ibhn3 ) , rtdwData , 0 , 21 , sizeof (
dqykr4eggmg . otjykwnhb3s . cosb2ibhn3 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. fuo05buemm ) , rtdwData , 0 , 22 , sizeof ( dqykr4eggmg . otjykwnhb3s .
fuo05buemm ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . ppp4ajc3p1 ) , rtdwData , 0 , 23 , sizeof (
dqykr4eggmg . otjykwnhb3s . ppp4ajc3p1 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. cfcgwprtdx ) , rtdwData , 0 , 24 , sizeof ( dqykr4eggmg . otjykwnhb3s .
cfcgwprtdx ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . npsllq52wf ) , rtdwData , 0 , 25 , sizeof (
dqykr4eggmg . otjykwnhb3s . npsllq52wf ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. i13qoukcsn ) , rtdwData , 0 , 26 , sizeof ( dqykr4eggmg . otjykwnhb3s .
i13qoukcsn ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . dxm3w2i52x ) , rtdwData , 0 , 27 , sizeof (
dqykr4eggmg . otjykwnhb3s . dxm3w2i52x ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ik5zcuhoy3 ) , rtdwData , 0 , 28 , sizeof ( dqykr4eggmg . otjykwnhb3s .
ik5zcuhoy3 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . lfi3mnae2m ) , rtdwData , 0 , 29 , sizeof (
dqykr4eggmg . otjykwnhb3s . lfi3mnae2m ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. lpva1qajzk ) , rtdwData , 0 , 30 , sizeof ( dqykr4eggmg . otjykwnhb3s .
lpva1qajzk ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . dhhdwwczx2 ) , rtdwData , 0 , 31 , sizeof (
dqykr4eggmg . otjykwnhb3s . dhhdwwczx2 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ii2o5s5qnf ) , rtdwData , 0 , 32 , sizeof ( dqykr4eggmg . otjykwnhb3s .
ii2o5s5qnf ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gafzug4yea ) , rtdwData , 0 , 33 , sizeof (
dqykr4eggmg . otjykwnhb3s . gafzug4yea ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. nuogwfijir ) , rtdwData , 0 , 34 , sizeof ( dqykr4eggmg . otjykwnhb3s .
nuogwfijir ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . hihnlferdi ) , rtdwData , 0 , 35 , sizeof (
dqykr4eggmg . otjykwnhb3s . hihnlferdi ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. pxamy50saq ) , rtdwData , 0 , 36 , sizeof ( dqykr4eggmg . otjykwnhb3s .
pxamy50saq ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . btfjf5acqg ) , rtdwData , 0 , 37 , sizeof (
dqykr4eggmg . otjykwnhb3s . btfjf5acqg ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. oa1muqt4on ) , rtdwData , 0 , 38 , sizeof ( dqykr4eggmg . otjykwnhb3s .
oa1muqt4on ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . h0cudiu0ft ) , rtdwData , 0 , 39 , sizeof (
dqykr4eggmg . otjykwnhb3s . h0cudiu0ft ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. iu11iwpdyn ) , rtdwData , 0 , 40 , sizeof ( dqykr4eggmg . otjykwnhb3s .
iu11iwpdyn ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . b3ewiobpsi ) , rtdwData , 0 , 41 , sizeof (
dqykr4eggmg . otjykwnhb3s . b3ewiobpsi ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ozjz0fr0k4 ) , rtdwData , 0 , 42 , sizeof ( dqykr4eggmg . otjykwnhb3s .
ozjz0fr0k4 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . pvn1aiza5a ) , rtdwData , 0 , 43 , sizeof (
dqykr4eggmg . otjykwnhb3s . pvn1aiza5a ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. j20mj4ai3a ) , rtdwData , 0 , 44 , sizeof ( dqykr4eggmg . otjykwnhb3s .
j20mj4ai3a ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . bgpppixzwr ) , rtdwData , 0 , 45 , sizeof (
dqykr4eggmg . otjykwnhb3s . bgpppixzwr ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. cmab1dak24 ) , rtdwData , 0 , 46 , sizeof ( dqykr4eggmg . otjykwnhb3s .
cmab1dak24 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . jtnjtissuf ) , rtdwData , 0 , 47 , sizeof (
dqykr4eggmg . otjykwnhb3s . jtnjtissuf ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ciy1c2o0rv . fau3qf03xm ) , rtdwData , 0 , 48 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ciy1c2o0rv . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. jvbbqhrajh . fau3qf03xm ) , rtdwData , 0 , 49 , sizeof ( dqykr4eggmg .
otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. clwiujjdqo . fau3qf03xm ) , rtdwData , 0 , 50 , sizeof ( dqykr4eggmg .
otjykwnhb3s . clwiujjdqo . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. acfz1zxm4t . fau3qf03xm ) , rtdwData , 0 , 51 , sizeof ( dqykr4eggmg .
otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ghadbep3bbv . fau3qf03xm ) , rtdwData , 0 , 52 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) ) ; } } void
mr_flightControlSystem_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 2179804220U , 1558893042U , 1682540665U ,
2366553530U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"flightControlSystem" , & chksum [ 0 ] ) ; } mxArray *
mr_flightControlSystem_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 1 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 1 ] = { "MATLABSystem" , } ; static const char * blockPath
[ 1 ] = {
"flightControlSystem/Image Processing System/PARROT Image Conversion" , } ;
static const int reason [ 1 ] = { 3 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] <
1 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript (
data , 2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType [
subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data , 2
, subs ) ; mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [ 0
] ] ) ) ; subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs )
; mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [ subs
[ 0 ] ] ) ) ; } } return data ; } static void *
flightControlSystem_InitRestoreDataPtr = NULL ; void
mr_flightControlSystem_CreateInitRestoreData ( ) {
flightControlSystem_InitRestoreDataPtr = utMalloc ( sizeof ( dqykr4eggmg ) )
; memcpy ( flightControlSystem_InitRestoreDataPtr , ( void * ) & (
dqykr4eggmg ) , sizeof ( dqykr4eggmg ) ) ; } void
mr_flightControlSystem_CopyFromInitRestoreData ( ) { memcpy ( ( void * ) & (
dqykr4eggmg ) , flightControlSystem_InitRestoreDataPtr , sizeof ( dqykr4eggmg
) ) ; } void mr_flightControlSystem_DestroyInitRestoreData ( ) { utFree (
flightControlSystem_InitRestoreDataPtr ) ; }
