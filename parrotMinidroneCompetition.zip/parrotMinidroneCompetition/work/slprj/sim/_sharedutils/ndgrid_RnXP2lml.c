#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "ndgrid_RnXP2lml.h"

void ndgrid_RnXP2lml(const real_T varargin_1[120], const real_T varargin_2[160],
                     real_T varargout_1[19200], real_T varargout_2[19200])
{
  int32_T k;
  int32_T c_k;
  for (k = 0; k < 160; k++) {
    memcpy(&varargout_1[k * 120], &varargin_1[0], 120U * sizeof(real_T));
    for (c_k = 0; c_k < 120; c_k++) {
      varargout_2[c_k + 120 * k] = varargin_2[k];
    }
  }
}
